const API_BASE = 'http://localhost:8000/api';
const WS_BASE = 'ws://localhost:8000/ws/notifications/';

export const getToken = () => localStorage.getItem('loanpulse_token');
export const setToken = (token) => localStorage.setItem('loanpulse_token', token);
export const getUser = () => {
  const user = localStorage.getItem('loanpulse_user');
  return user ? JSON.parse(user) : null;
};
export const setUser = (user) => localStorage.setItem('loanpulse_user', JSON.stringify(user));
export const clearAuth = () => {
  localStorage.removeItem('loanpulse_token');
  localStorage.removeItem('loanpulse_user');
};

async function request(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Handle FormData vs JSON
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  const url = `${API_BASE}${endpoint}`;
  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (response.status === 401) {
      // Token expired or invalid
      // Do not clear immediately on login endpoint itself
      if (!endpoint.includes('/auth/login/')) {
        clearAuth();
        window.dispatchEvent(new Event('loanpulse_auth_expired'));
      }
    }

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw { status: response.status, data };
    }
    return data;
  } catch (err) {
    throw err;
  }
}

export const api = {
  // Authentication
  login: async (username, password) => {
    const data = await request('/auth/login/', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    setToken(data.access);
    setUser(data.user);
    return data;
  },

  register: (userData) =>
    request('/auth/register/', {
      method: 'POST',
      body: JSON.stringify(userData),
    }),

  getProfile: () => request('/auth/me/'),

  // Notifications & Audit
  getNotifications: () => request('/notifications/'),
  markNotificationsRead: () =>
    request('/notifications/mark-read/', { method: 'POST' }),
  getAuditLogs: (appNo = '') =>
    request(`/audit-logs/${appNo ? `?application_number=${appNo}` : ''}`),

  // Loan Products & EMI
  getLoanProducts: () => request('/loans/products/'),
  calculateEMI: (amount, interest_rate, tenure_months) =>
    request('/loans/calculate-emi/', {
      method: 'POST',
      body: JSON.stringify({ amount, interest_rate, tenure_months }),
    }),

  // Customer Actions
  getCustomerApplications: () => request('/loans/customer/applications/'),
  submitLoanApplication: (payload) =>
    request('/loans/customer/applications/', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getCustomerActiveLoans: () => request('/loans/customer/active-loans/'),
  payEMI: (emiId) =>
    request(`/loans/customer/pay-emi/${emiId}/`, {
      method: 'POST',
    }),

  // Documents & OCR
  uploadDocument: (formData) =>
    request('/documents/upload/', {
      method: 'POST',
      body: formData,
    }),
  verifySelfie: (imageDataOrBlob) => {
    if (typeof imageDataOrBlob === 'string') {
      return request('/documents/upload/', {
        method: 'POST',
        body: JSON.stringify({
          document_type: 'SELFIE',
          image_data: imageDataOrBlob,
        }),
      });
    } else {
      const form = new FormData();
      form.append('file', imageDataOrBlob);
      form.append('document_type', 'SELFIE');
      return request('/documents/upload/', {
        method: 'POST',
        body: form,
      });
    }
  },
  reviewDocument: (docId, action, remarks) =>
    request(`/documents/${docId}/review/`, {
      method: 'POST',
      body: JSON.stringify({ action, remarks }),
    }),

  // Employee Actions
  getEmployeeApplications: (status = '') =>
    request(`/loans/employee/applications/${status ? `?status=${status}` : ''}`),
  getApplicationDetail: (appId) => request(`/loans/applications/${appId}/`),
  submitVerificationReport: (appId, payload) =>
    request(`/loans/employee/applications/${appId}/submit-report/`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Manager Actions
  getManagerStats: () => request('/loans/manager/stats/'),
  submitManagerDecision: (appId, decision, remarks) =>
    request(`/loans/manager/applications/${appId}/decision/`, {
      method: 'POST',
      body: JSON.stringify({ decision, remarks }),
    }),

  // Simulations & AI RAG
  simulateOverdue: (emiId) =>
    request(`/loans/simulate-overdue/${emiId}/`, {
      method: 'POST',
    }),
  simulateRisk: (data) =>
    request('/risk/simulate/', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  ragQuery: (query) =>
    request('/risk/rag-query/', {
      method: 'POST',
      body: JSON.stringify({ query }),
    }),
};

// WebSocket Service for live notifications
export class NotificationWebSocket {
  constructor(onNotification, onConnectionChange) {
    this.onNotification = onNotification;
    this.onConnectionChange = onConnectionChange;
    this.socket = null;
    this.reconnectTimer = null;
    this.isExplicitlyClosed = false;
  }

  connect() {
    this.isExplicitlyClosed = false;
    const token = getToken();
    const wsUrl = `${WS_BASE}?token=${token || ''}`;

    try {
      this.socket = new WebSocket(wsUrl);

      this.socket.onopen = () => {
        if (this.onConnectionChange) this.onConnectionChange(true);
      };

      this.socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'NOTIFICATION' && this.onNotification) {
            this.onNotification(payload.payload);
          }
        } catch (e) {
          console.error('WS Parse Error:', e);
        }
      };

      this.socket.onclose = () => {
        if (this.onConnectionChange) this.onConnectionChange(false);
        if (!this.isExplicitlyClosed) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = setTimeout(() => this.connect(), 4000);
        }
      };

      this.socket.onerror = () => {
        if (this.socket) this.socket.close();
      };
    } catch (e) {
      console.warn('WebSocket connection not reachable, fallback to polling:', e);
    }
  }

  close() {
    this.isExplicitlyClosed = true;
    clearTimeout(this.reconnectTimer);
    if (this.socket) {
      this.socket.close();
    }
  }
}
