import React, { useState } from 'react';
import { 
  Bot, Shield, Lock, Send, Sparkles, AlertCircle, 
  CheckCircle2, X, BookOpen, Key, Eye, EyeOff, RefreshCw
} from 'lucide-react';
import { api } from '../api';

export default function RAGAssistantModal({ isOpen, onClose, userContext }) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [showPrivacyDetails, setShowPrivacyDetails] = useState(true);

  if (!isOpen) return null;

  const quickPrompts = [
    "How does my CIBIL score affect my loan interest rate and eligibility?",
    "Can I prepay my loan early without paying foreclosure penalties?",
    "What are the maximum Debt-To-Income (DTI) ratio rules for salaried applicants?",
    "My PAN is ABCDE1234F, phone 9876543210. How will this test PII masking in RAG?"
  ];

  const handleSend = async (questionText) => {
    const textToSend = questionText || query;
    if (!textToSend.trim()) return;

    setLoading(true);
    try {
      const data = await api.ragQuery(textToSend);
      setResult(data);
    } catch (err) {
      console.error('RAG query failed:', err);
      alert('Failed to process RAG query.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-700 to-blue-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Privacy-Preserving RAG Assistant</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-extrabold border border-emerald-200 flex items-center gap-1">
                  <Shield className="w-3 h-3" />
                  DPDP & RBI Guardrails Active
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Institutional credit policy retrieval with automated customer PII sanitization to prevent privacy violations.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Privacy Guardrails Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 text-xs text-emerald-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-emerald-900">Zero-Data-Leakage Architecture</p>
              <p className="text-[11px] text-emerald-800 mt-0.5">
                Full PAN, 12-digit Aadhaar UID, account numbers, and phone numbers are automatically intercepted and redacted before prompt dispatch.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowPrivacyDetails(!showPrivacyDetails)}
            className="px-2.5 py-1 rounded-lg bg-white/80 border border-emerald-200 text-[10px] font-bold text-emerald-800 hover:bg-white shrink-0 flex items-center gap-1"
          >
            {showPrivacyDetails ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            <span>{showPrivacyDetails ? 'Hide Inspector' : 'Show Inspector'}</span>
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
            Suggested Policy Questions
          </span>
          <div className="flex flex-wrap gap-1.5">
            {quickPrompts.map((q, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setQuery(q);
                  handleSend(q);
                }}
                className="text-left text-xs px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Query Input Box */}
        <div className="relative">
          <textarea
            rows="2"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask anything about CIBIL scoring, interest rates, DTI rules, or test PII masking..."
            className="w-full p-3.5 pr-12 text-xs bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white resize-none"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !query.trim()}
            className="absolute right-3 top-3 p-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl shadow-xs transition-all"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>

        {/* Result Area */}
        {result && (
          <div className="space-y-4 animate-fade-in">
            
            {/* Live Privacy Inspection Box */}
            {showPrivacyDetails && (
              <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 text-xs font-mono">
                <div className="flex items-center justify-between pb-2 border-b border-white/10 font-sans">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" />
                    Privacy Guardrail Verification Receipt
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Token: {result.privacy_compliance.audit_verification_token}
                  </span>
                </div>

                <div className="space-y-2 text-[11px]">
                  <div>
                    <span className="text-slate-400 block mb-0.5 font-sans font-semibold">1. Original Input Query:</span>
                    <p className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-300">
                      {result.original_query}
                    </p>
                  </div>

                  <div>
                    <span className="text-slate-400 block mb-0.5 font-sans font-semibold">2. Sanitized Prompt Sent to RAG/LLM:</span>
                    <p className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
                      {result.sanitized_query}
                    </p>
                  </div>

                  {result.pii_detected_and_masked.length > 0 && (
                    <div>
                      <span className="text-amber-400 block mb-0.5 font-sans font-semibold">3. Intercepted PII Entities:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {result.pii_detected_and_masked.map((entity, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px]">
                            {entity.type}: {entity.action}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between text-[10px] text-slate-400 pt-1 font-sans">
                    <span>Data Leakage Risk: <strong className="text-emerald-400">{result.privacy_compliance.data_leakage_risk}</strong></span>
                    <span>DPDP Act 2023: <strong className="text-emerald-400">ENFORCED</strong></span>
                  </div>
                </div>
              </div>
            )}

            {/* Answer Box */}
            <div className="p-5 rounded-2xl bg-blue-50/60 border border-blue-100 text-xs text-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-blue-900 font-bold">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span>RAG Verified Underwriting Response</span>
              </div>
              <div className="leading-relaxed whitespace-pre-line">
                {result.answer}
              </div>

              {/* Citations */}
              {result.retrieved_policies?.length > 0 && (
                <div className="pt-3 border-t border-blue-200/60">
                  <span className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Grounded Policy Citations:
                  </span>
                  <div className="flex flex-wrap gap-2 text-[10px]">
                    {result.retrieved_policies.map((p, i) => (
                      <span key={i} className="px-2 py-1 rounded-md bg-white border border-blue-200 text-blue-950 font-medium">
                        [{p.id}] {p.citation}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

        <div className="text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Close Assistant
          </button>
        </div>

      </div>
    </div>
  );
}
