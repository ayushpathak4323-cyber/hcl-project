import React, { useState, useEffect } from 'react';
import { 
  Briefcase, CheckCircle2, AlertTriangle, FileText, 
  Eye, Check, X, Shield, Clock, ArrowRight, MessageSquare, 
  TrendingUp, RefreshCw, AlertCircle, FileCheck, Layers, Sparkles,
  Camera, UserCheck
} from 'lucide-react';
import { api } from '../api';

export default function EmployeeDashboard({ user, onRefreshBadge }) {
  const [metrics, setMetrics] = useState({
    total_applications: 0,
    pending_verification: 0,
    documents_pending: 0,
    verified: 0,
    rejected: 0,
  });
  const [applications, setApplications] = useState([]);
  const [filterStatus, setFilterStatus] = useState('');
  const [loading, setLoading] = useState(true);

  // Active Review Modal Workspace
  const [selectedApp, setSelectedApp] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [verificationRemarks, setVerificationRemarks] = useState('');
  const [recommendation, setRecommendation] = useState('RECOMMENDED_APPROVAL');
  const [submittingReport, setSubmittingReport] = useState(false);

  useEffect(() => {
    loadApplications();
  }, [filterStatus]);

  const loadApplications = async () => {
    setLoading(true);
    try {
      const data = await api.getEmployeeApplications(filterStatus);
      setMetrics(data.metrics);
      setApplications(data.applications);
    } catch (err) {
      console.error('Failed to load employee applications:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDossier = async (appId) => {
    setLoadingDetail(true);
    try {
      const detail = await api.getApplicationDetail(appId);
      setSelectedApp(detail);
      setVerificationRemarks(detail.employee_remarks || '');
      // Refresh list in background to reflect status transition to UNDER_REVIEW
      loadApplications();
    } catch (err) {
      console.error('Failed to open application dossier:', err);
    } finally {
      setLoadingDetail(false);
    }
  };

  // Review single document (Verify or Reject)
  const handleReviewDocument = async (docId, action) => {
    let remarks = '';
    if (action === 'REJECT') {
      remarks = prompt('Enter specific rejection reason for customer notification:', 'Image blurry / details not legible under OCR scan.');
      if (!remarks) return;
    }

    try {
      await api.reviewDocument(docId, action, remarks);
      // Refresh active dossier
      const updated = await api.getApplicationDetail(selectedApp.id);
      setSelectedApp(updated);
      loadApplications();
      if (onRefreshBadge) onRefreshBadge();
    } catch (err) {
      console.error(err);
      alert('Failed to update document verification status.');
    }
  };

  // Submit Final Verification Report
  const handleSubmitReport = async () => {
    if (!verificationRemarks) {
      alert('Please enter officer verification remarks.');
      return;
    }

    setSubmittingReport(true);
    try {
      await api.submitVerificationReport(selectedApp.id, {
        recommendation,
        remarks: verificationRemarks,
      });
      alert(`Verification report successfully submitted. Application status changed to EMPLOYEE_VERIFIED and forwarded to Manager for final approval.`);
      setSelectedApp(null);
      await loadApplications();
      if (onRefreshBadge) onRefreshBadge();
    } catch (err) {
      console.error('Failed to submit verification report:', err);
      alert('Failed to submit verification report.');
    } finally {
      setSubmittingReport(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'EMPLOYEE_VERIFIED':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'UNDER_REVIEW':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'SUBMITTED':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'REJECTED':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Officer Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 card-shadow">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
              Loan Officer Code: {user?.employee_id || 'EMP104'}
            </span>
            <span className="text-xs text-slate-400">• Underwriting Queue</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            Application Verification Workspace
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Validate applicant KYC documents, inspect OCR classification confidence, review financial DTI metrics, and submit verification dossiers.
          </p>
        </div>

        <button
          onClick={loadApplications}
          className="px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 flex items-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div 
          onClick={() => setFilterStatus('')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all card-shadow ${
            filterStatus === '' ? 'bg-blue-50/70 border-blue-300' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-bold uppercase text-slate-500">Total Applications</span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">{metrics.total_applications}</p>
        </div>

        <div 
          onClick={() => setFilterStatus('SUBMITTED')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all card-shadow ${
            filterStatus === 'SUBMITTED' ? 'bg-amber-50/70 border-amber-300' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-bold uppercase text-amber-700">Pending Review</span>
          <p className="text-2xl font-extrabold text-amber-800 mt-1">{metrics.pending_verification}</p>
        </div>

        <div 
          onClick={() => setFilterStatus('UNDER_REVIEW')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all card-shadow ${
            filterStatus === 'UNDER_REVIEW' ? 'bg-indigo-50/70 border-indigo-300' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-bold uppercase text-indigo-700">Documents Pending</span>
          <p className="text-2xl font-extrabold text-indigo-800 mt-1">{metrics.documents_pending}</p>
        </div>

        <div 
          onClick={() => setFilterStatus('EMPLOYEE_VERIFIED')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all card-shadow ${
            filterStatus === 'EMPLOYEE_VERIFIED' ? 'bg-purple-50/70 border-purple-300' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-bold uppercase text-purple-700">Verified Dossiers</span>
          <p className="text-2xl font-extrabold text-purple-800 mt-1">{metrics.verified}</p>
        </div>

        <div 
          onClick={() => setFilterStatus('REJECTED')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all card-shadow ${
            filterStatus === 'REJECTED' ? 'bg-rose-50/70 border-rose-300' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-bold uppercase text-rose-700">Rejected</span>
          <p className="text-2xl font-extrabold text-rose-800 mt-1">{metrics.rejected}</p>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 card-shadow space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">Assigned Applications Queue</h2>
            <p className="text-xs text-slate-500">
              {filterStatus ? `Showing filtered status: ${filterStatus}` : 'Showing all applications across stages'}
            </p>
          </div>

          {filterStatus && (
            <button
              onClick={() => setFilterStatus('')}
              className="text-xs text-blue-600 font-bold hover:underline"
            >
              Clear Filter
            </button>
          )}
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Application #</th>
                <th className="py-3 px-4">Applicant</th>
                <th className="py-3 px-4">Product</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Risk Score</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4 text-right">Verification Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {applications.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-8 text-slate-400">
                    No loan applications matching the selected criteria.
                  </td>
                </tr>
              ) : (
                applications.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-blue-700">#{app.application_number}</td>
                    <td className="py-3 px-4 font-medium text-slate-900">{app.customer_name}</td>
                    <td className="py-3 px-4 text-slate-700">{app.loan_product_name}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">₹{Number(app.requested_amount).toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4">
                      {app.risk_score ? (
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          app.risk_level === 'LOW' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {app.risk_score}/100 • {app.risk_level}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-mono">Pending</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full font-semibold text-[10px] border ${getStatusColor(app.status)}`}>
                        {app.status_display || app.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">{new Date(app.created_at).toLocaleDateString()}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleOpenDossier(app.id)}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs"
                      >
                        Open Dossier
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* VERIFICATION DOSSIER WORKSPACE MODAL */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-bold text-blue-700">#{selectedApp.application_number}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${getStatusColor(selectedApp.status)}`}>
                    {selectedApp.status_display || selectedApp.status}
                  </span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 mt-1">
                  Applicant: {selectedApp.customer_name} ({selectedApp.customer_email})
                </h2>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Financial & Loan Overview Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <span className="text-slate-400 font-medium">Monthly Income</span>
                <p className="font-extrabold text-slate-900 mt-0.5">
                  ₹{Number(selectedApp.customer_profile?.monthly_income || 0).toLocaleString('en-IN')}
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Employer / Company</span>
                <p className="font-extrabold text-slate-900 mt-0.5 truncate">
                  {selectedApp.customer_profile?.company_name || 'N/A'}
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Existing Debt EMI</span>
                <p className="font-extrabold text-slate-900 mt-0.5">
                  ₹{Number(selectedApp.customer_profile?.existing_monthly_emi || 0).toLocaleString('en-IN')} ({selectedApp.customer_profile?.existing_loans} loans)
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Requested Loan</span>
                <p className="font-extrabold text-blue-700 mt-0.5">
                  ₹{Number(selectedApp.requested_amount).toLocaleString('en-IN')} ({selectedApp.tenure_months} mos)
                </p>
              </div>
            </div>

            {/* Risk Assessment Scoring Panel */}
            {selectedApp.risk_assessment && (
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950 text-white space-y-4 shadow-xl">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-400" />
                    <span className="text-sm font-bold">Credit Risk Assessment Engine (Advisory)</span>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-black uppercase ${
                    selectedApp.risk_assessment.risk_level === 'LOW'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-400/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-400/30'
                  }`}>
                    {selectedApp.risk_assessment.score} / 100 • {selectedApp.risk_assessment.risk_level} RISK
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-slate-400 text-[11px]">DTI Ratio</span>
                    <p className="font-extrabold text-white mt-0.5 text-sm">{selectedApp.risk_assessment.debt_to_income_ratio}%</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-slate-400 text-[11px]">Loan/Income (LTI)</span>
                    <p className="font-extrabold text-white mt-0.5 text-sm">{selectedApp.risk_assessment.loan_to_income_ratio}x</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-slate-400 text-[11px]">Stability Score</span>
                    <p className="font-extrabold text-emerald-400 mt-0.5 text-sm">{selectedApp.risk_assessment.income_stability_score} pts</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-slate-400 text-[11px]">Debt Burden</span>
                    <p className="font-extrabold text-white mt-0.5 text-sm">{selectedApp.risk_assessment.existing_debt_score} pts</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-blue-100/90 leading-relaxed">
                  <p className="font-semibold text-white mb-1">Underwriting Narrative:</p>
                  <p>{selectedApp.risk_assessment.recommendation_summary}</p>
                </div>
              </div>
            )}

            {/* Document Inspection & OCR Results Workspace */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Uploaded KYC Documents & OCR Classification ({selectedApp.documents?.length || 0})
                </h3>
                <span className="text-[11px] text-slate-400">
                  Verify or reject individual documents with real-time customer alert
                </span>
              </div>

              <div className="space-y-3">
                {selectedApp.documents?.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-all card-shadow space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900 text-xs">{doc.document_type_display}</p>
                          <p className="text-[11px] text-slate-400 font-mono">{doc.file_name} • {(doc.file_size / 1024).toFixed(1)} KB</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                          doc.verification_status === 'VERIFIED' || doc.verification_status === 'AUTO_VERIFIED'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : doc.verification_status === 'REJECTED'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}>
                          {doc.verification_status_display}
                        </span>

                        {doc.verification_status !== 'VERIFIED' && (
                          <button
                            onClick={() => handleReviewDocument(doc.id, 'VERIFY')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg flex items-center gap-1 shadow-xs"
                          >
                            <Check className="w-3 h-3" />
                            <span>Verify</span>
                          </button>
                        )}

                        {doc.verification_status !== 'REJECTED' && (
                          <button
                            onClick={() => handleReviewDocument(doc.id, 'REJECT')}
                            className="px-2.5 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-[11px] font-bold rounded-lg flex items-center gap-1"
                          >
                            <X className="w-3 h-3" />
                            <span>Reject</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Biometric Selfie View or OCR Text Snippet */}
                    {doc.document_type === 'SELFIE' ? (
                      <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-blue-900 flex items-center gap-1.5">
                            <Camera className="w-4 h-4 text-blue-600" />
                            Live Video-KYC Facial Inspection
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold border border-emerald-300">
                            RBI V-CIP Compliant
                          </span>
                        </div>
                        <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
                          {doc.file ? (
                            <img
                              src={doc.file}
                              alt="Applicant KYC Selfie"
                              className="w-20 h-20 rounded-xl object-cover border-2 border-blue-400 shadow-xs shrink-0"
                            />
                          ) : (
                            <div className="w-20 h-20 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs shrink-0">
                              Selfie Photo
                            </div>
                          )}
                          <div className="flex-1 space-y-1 text-slate-700">
                            <div className="grid grid-cols-2 gap-2 text-[11px]">
                              <div className="p-1.5 rounded-lg bg-white border border-blue-100">
                                <span className="text-slate-400 text-[10px] block">Liveness Score</span>
                                <strong className="text-emerald-700">{doc.extracted_metadata?.liveness_score || 98.4}% (PASS)</strong>
                              </div>
                              <div className="p-1.5 rounded-lg bg-white border border-blue-100">
                                <span className="text-slate-400 text-[10px] block">ID Face Match</span>
                                <strong className="text-emerald-700">{doc.confidence_score}% Match</strong>
                              </div>
                            </div>
                            <p className="text-[11px] text-slate-500 pt-0.5">
                              Passive liveness verified: No spoofing or digital screen reproduction detected.
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 font-mono">
                        <div className="flex justify-between text-slate-400 mb-1 font-sans font-semibold">
                          <span>OCR Extracted Text Sample</span>
                          <span>Confidence: <strong className="text-emerald-700">{doc.confidence_score}%</strong></span>
                        </div>
                        <p className="line-clamp-2">{doc.ocr_extracted_text || '[No raw text extracted]'}</p>
                      </div>
                    )}

                    {doc.rejection_reason && (
                      <p className="text-xs text-rose-700 font-semibold bg-rose-50 p-2 rounded-lg border border-rose-200">
                        Rejection reason communicated to customer: {doc.rejection_reason}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Officer Final Report Form */}
            <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                Loan Officer Verification Report Submission
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Officer Underwriting Recommendation
                  </label>
                  <select
                    value={recommendation}
                    onChange={(e) => setRecommendation(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-200 rounded-xl"
                  >
                    <option value="RECOMMENDED_APPROVAL">Recommended for Approval (Standard Risk)</option>
                    <option value="RECOMMENDED_REJECTION">Recommended for Rejection (High Risk / Failure)</option>
                    <option value="MORE_INFO_NEEDED">More Information / Additional Documents Needed</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Officer Remarks & Underwriting Notes
                  </label>
                  <input
                    type="text"
                    value={verificationRemarks}
                    onChange={(e) => setVerificationRemarks(e.target.value)}
                    placeholder="All KYC documents match and verified against official database."
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-amber-800">
                  Submitting transitions status to <strong>EMPLOYEE_VERIFIED</strong> and alerts Manager in real time.
                </span>

                <button
                  onClick={handleSubmitReport}
                  disabled={submittingReport}
                  className="px-6 py-2.5 bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2"
                >
                  {submittingReport ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting Report...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Submit Verification Report to Manager</span>
                    </>
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
