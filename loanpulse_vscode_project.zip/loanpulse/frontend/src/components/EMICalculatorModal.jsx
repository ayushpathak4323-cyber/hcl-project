import React, { useState, useEffect } from 'react';
import { Calculator, X, DollarSign, Calendar, TrendingUp } from 'lucide-react';
import { api } from '../api';

export default function EMICalculatorModal({ isOpen, onClose }) {
  const [amount, setAmount] = useState(300000);
  const [rate, setRate] = useState(10.5);
  const [tenure, setTenure] = useState(24);
  const [result, setResult] = useState({
    calculated_emi: 0,
    total_interest: 0,
    total_repayment: 0,
  });

  useEffect(() => {
    if (isOpen) {
      api.calculateEMI(amount, rate, tenure)
        .then((res) => setResult(res))
        .catch((err) => console.error(err));
    }
  }, [isOpen, amount, rate, tenure]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">EMI & Amortization Calculator</h2>
              <p className="text-xs text-slate-500">Standard banking reducing-balance formula simulation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Sliders */}
        <div className="space-y-4 text-xs">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-slate-700 uppercase">Loan Amount</span>
              <span className="font-extrabold text-blue-700 text-sm">₹{amount.toLocaleString('en-IN')}</span>
            </div>
            <input
              type="range"
              min="25000"
              max="2000000"
              step="25000"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-slate-700 uppercase">Interest Rate (% p.a.)</span>
              <span className="font-extrabold text-blue-700 text-sm">{rate}%</span>
            </div>
            <input
              type="range"
              min="7.5"
              max="20.0"
              step="0.25"
              value={rate}
              onChange={(e) => setRate(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-slate-700 uppercase">Repayment Tenure (Months)</span>
              <span className="font-extrabold text-blue-700 text-sm">{tenure} Months</span>
            </div>
            <input
              type="range"
              min="6"
              max="60"
              step="6"
              value={tenure}
              onChange={(e) => setTenure(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Results Banner */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950 text-white space-y-3">
          <div className="flex justify-between items-center pb-2 border-b border-white/10">
            <span className="text-xs text-blue-200">Calculated Monthly EMI</span>
            <span className="text-2xl font-extrabold text-white">
              ₹{Number(result.calculated_emi).toLocaleString('en-IN')}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 text-center text-xs">
            <div>
              <span className="text-slate-400">Total Interest Payable</span>
              <p className="font-bold text-blue-200 mt-0.5">₹{Number(result.total_interest).toLocaleString('en-IN')}</p>
            </div>
            <div>
              <span className="text-slate-400">Total Principal + Interest</span>
              <p className="font-bold text-white mt-0.5">₹{Number(result.total_repayment).toLocaleString('en-IN')}</p>
            </div>
          </div>
        </div>

        <div className="text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Close Calculator
          </button>
        </div>

      </div>
    </div>
  );
}
