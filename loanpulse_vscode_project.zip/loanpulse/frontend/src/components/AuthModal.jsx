import React, { useState } from 'react';
import { 
  Shield, User, Briefcase, Award, ArrowRight, Lock, 
  Mail, Phone, AlertCircle, CheckCircle2, Building, DollarSign
} from 'lucide-react';
import { api } from '../api';

export default function AuthModal({ onLoginSuccess }) {
  const [selectedRole, setSelectedRole] = useState('CUSTOMER'); // CUSTOMER, EMPLOYEE, MANAGER
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  
  // Login Form State
  const [username, setUsername] = useState('customer@loanpulse.com');
  const [password, setPassword] = useState('password123');

  // Registration Form State (for Customers)
  const [regData, setRegData] = useState({
    username: '',
    email: '',
    password: '',
    first_name: '',
    last_name: '',
    phone: '',
    monthly_income: '75000',
    company_name: 'Tata Consultancy Services',
    city: 'Mumbai',
    state: 'Maharashtra'
  });

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
    setIsRegistering(false);
    setErrorMessage('');
    
    // Auto-fill default demo credentials for the role
    if (role === 'CUSTOMER') {
      setUsername('customer@loanpulse.com');
      setPassword('password123');
    } else if (role === 'EMPLOYEE') {
      setUsername('employee@loanpulse.com');
      setPassword('password123');
    } else if (role === 'MANAGER') {
      setUsername('manager@loanpulse.com');
      setPassword('password123');
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    try {
      const data = await api.login(username, password);
      // Validate that role matches selected role
      if (data.user.role !== selectedRole) {
        setErrorMessage(
          `Access Denied: Account belongs to role '${data.user.role}', but you selected '${selectedRole} Login'. Please choose the correct portal tab.`
        );
        setLoading(false);
        return;
      }
      onLoginSuccess(data.user);
    } catch (err) {
      console.error(err);
      setErrorMessage(
        err.data?.detail || err.data?.error || 'Invalid credentials or connection failure. Please verify email and password.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    try {
      await api.register(regData);
      // Automatically log in newly registered customer
      const loginData = await api.login(regData.username, regData.password);
      onLoginSuccess(loginData.user);
    } catch (err) {
      console.error(err);
      const errors = err.data || {};
      const firstError = Object.values(errors).flat()[0] || 'Registration failed. Please check your details.';
      setErrorMessage(firstError);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-blue-600/20 via-indigo-600/15 to-transparent rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>
      
      {/* Brand Header */}
      <div className="text-center mb-8 max-w-xl relative z-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-400/20 text-blue-300 text-xs font-semibold mb-4 backdrop-blur-md">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Next-Gen Enterprise Lending Core v2.5</span>
        </div>

        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-blue-500 shadow-xl shadow-blue-500/30 flex items-center justify-center text-white">
            <Shield className="w-7 h-7" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
            LoanPulse
          </h1>
        </div>

        <p className="text-sm font-medium text-slate-300">
          Loan Management & Risk Assessment System
        </p>

        {/* Feature Badges Grid */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px] text-slate-300">
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
            3-Layer Architecture
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            CIBIL Scoring Engine
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
            DPDP-Safe RAG Assistant
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
            OCR Document Validation
          </span>
        </div>
      </div>

      {/* Main Card */}
      <div className="w-full max-w-xl bg-white text-slate-900 rounded-3xl shadow-2xl border border-slate-100/20 overflow-hidden relative z-10 card-shadow">
        
        {/* Three Portal Selector Tabs */}
        {!isRegistering && (
          <div className="grid grid-cols-3 border-b border-slate-200 bg-slate-50 p-1.5 gap-1.5">
            <button
              type="button"
              onClick={() => handleRoleSelect('CUSTOMER')}
              className={`flex flex-col items-center py-3 px-2 rounded-xl text-xs font-bold transition-all ${
                selectedRole === 'CUSTOMER'
                  ? 'bg-white text-blue-700 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <User className="w-4 h-4 mb-1 text-blue-600" />
              <span>Customer</span>
              <span className="text-[10px] font-normal text-slate-500 hidden sm:inline">Borrower Portal</span>
            </button>

            <button
              type="button"
              onClick={() => handleRoleSelect('EMPLOYEE')}
              className={`flex flex-col items-center py-3 px-2 rounded-xl text-xs font-bold transition-all ${
                selectedRole === 'EMPLOYEE'
                  ? 'bg-white text-amber-700 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Briefcase className="w-4 h-4 mb-1 text-amber-600" />
              <span>Employee</span>
              <span className="text-[10px] font-normal text-slate-500 hidden sm:inline">Loan Officer</span>
            </button>

            <button
              type="button"
              onClick={() => handleRoleSelect('MANAGER')}
              className={`flex flex-col items-center py-3 px-2 rounded-xl text-xs font-bold transition-all ${
                selectedRole === 'MANAGER'
                  ? 'bg-white text-purple-700 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Award className="w-4 h-4 mb-1 text-purple-600" />
              <span>Manager</span>
              <span className="text-[10px] font-normal text-slate-500 hidden sm:inline">Credit Committee</span>
            </button>
          </div>
        )}

        <div className="p-6 sm:p-8">
          
          {/* Quick Demo Preload Pill */}
          {!isRegistering && (
            <div className="mb-6 p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
              <span className="text-slate-600 font-medium">
                Demo Account: <strong className="text-slate-900">{username}</strong>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold text-[11px]">
                Preloaded Password: password123
              </span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-6 p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-800 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Form */}
          {!isRegistering ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Email Address / Username
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`w-full py-3 px-4 rounded-xl text-sm font-bold text-white shadow-md transition-all flex items-center justify-center gap-2 ${
                  selectedRole === 'CUSTOMER'
                    ? 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
                    : selectedRole === 'EMPLOYEE'
                    ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-500/20'
                    : 'bg-purple-600 hover:bg-purple-700 shadow-purple-500/20'
                }`}
              >
                {loading ? 'Authenticating...' : `Sign In as ${selectedRole.charAt(0) + selectedRole.slice(1).toLowerCase()}`}
                {!loading && <ArrowRight className="w-4 h-4" />}
              </button>

              {/* Demo Fast Switcher Buttons */}
              <div className="pt-4 border-t border-slate-100">
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider text-center mb-2.5">
                  1-Click Role Switcher For Evaluators
                </p>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleRoleSelect('CUSTOMER')}
                    className="py-1.5 px-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-center border border-blue-100"
                  >
                    Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRoleSelect('EMPLOYEE')}
                    className="py-1.5 px-2 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 font-semibold text-center border border-amber-100"
                  >
                    Loan Officer
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRoleSelect('MANAGER')}
                    className="py-1.5 px-2 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 font-semibold text-center border border-purple-100"
                  >
                    Manager
                  </button>
                </div>
              </div>

              {selectedRole === 'CUSTOMER' && (
                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => setIsRegistering(true)}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                  >
                    New Customer? Create a Loan Account
                  </button>
                </div>
              )}
            </form>
          ) : (
            /* Registration Form for Customers */
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h3 className="font-bold text-slate-900 text-sm">Customer Registration</h3>
                <button
                  type="button"
                  onClick={() => setIsRegistering(false)}
                  className="text-xs text-blue-600 font-semibold hover:underline"
                >
                  Back to Sign In
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">First Name</label>
                  <input
                    type="text"
                    required
                    value={regData.first_name}
                    onChange={(e) => setRegData({ ...regData, first_name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="Rahul"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Last Name</label>
                  <input
                    type="text"
                    required
                    value={regData.last_name}
                    onChange={(e) => setRegData({ ...regData, last_name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="Sharma"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Email / Username</label>
                <input
                  type="email"
                  required
                  value={regData.username}
                  onChange={(e) => setRegData({ ...regData, username: e.target.value, email: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                  placeholder="rahul.sharma@example.com"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Phone</label>
                  <input
                    type="text"
                    value={regData.phone}
                    onChange={(e) => setRegData({ ...regData, phone: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="9876543210"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Password</label>
                  <input
                    type="password"
                    required
                    value={regData.password}
                    onChange={(e) => setRegData({ ...regData, password: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Monthly Income (₹)</label>
                  <input
                    type="number"
                    value={regData.monthly_income}
                    onChange={(e) => setRegData({ ...regData, monthly_income: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="75000"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">Company</label>
                  <input
                    type="text"
                    value={regData.company_name}
                    onChange={(e) => setRegData({ ...regData, company_name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    placeholder="Infosys"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 rounded-xl text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-500/20 transition-all"
              >
                {loading ? 'Creating Account...' : 'Complete Registration & Sign In'}
              </button>
            </form>
          )}

        </div>

        {/* Security & Architecture Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1.5 font-medium">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            256-Bit SSL • JWT Token Auth
          </span>
          <span className="font-mono text-slate-400">Oracle Relational DB Layer</span>
        </div>

      </div>
    </div>
  );
}
