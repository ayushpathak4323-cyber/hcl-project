import React from 'react';
import { 
  Shield, Bell, User, LogOut, FileText, CheckCircle2, 
  Layers, Clock, RefreshCw, Calculator, History, Bot
} from 'lucide-react';

export default function Navbar({ 
  user, 
  onLogout, 
  unreadCount, 
  onToggleNotifications, 
  wsConnected, 
  activeTab, 
  setActiveTab,
  onOpenAuditLogs,
  onOpenCalculator,
  onOpenRAG,
  onSwitchRole
}) {
  const getRoleBadge = (role) => {
    switch (role) {
      case 'CUSTOMER':
        return { label: 'Customer Portal', bg: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'EMPLOYEE':
        return { label: 'Loan Officer [Verification]', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      case 'MANAGER':
        return { label: 'Manager [Credit Committee]', bg: 'bg-purple-50 text-purple-700 border-purple-200' };
      default:
        return { label: role, bg: 'bg-slate-50 text-slate-700 border-slate-200' };
    }
  };

  const badge = user ? getRoleBadge(user.role) : null;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-slate-900 to-blue-900 bg-clip-text text-transparent">
                  LoanPulse
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                  Enterprise
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">Loan Management & Risk Assessment System</p>
            </div>
          </div>

          {/* Navigation Links (Role Dependent) */}
          {user && (
            <div className="hidden md:flex items-center gap-1">
              {user.role === 'CUSTOMER' && (
                <>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'dashboard'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab('apply')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'apply'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Apply for Loan
                  </button>
                  <button
                    onClick={() => setActiveTab('applications')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'applications'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    My Applications
                  </button>
                  <button
                    onClick={() => setActiveTab('active-loans')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'active-loans'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Active Loans & EMI
                  </button>
                </>
              )}

              {user.role === 'EMPLOYEE' && (
                <>
                  <button
                    onClick={() => setActiveTab('verification')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'verification'
                        ? 'bg-amber-50 text-amber-800'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Verification Queue
                  </button>
                  <button
                    onClick={() => setActiveTab('documents')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'documents'
                        ? 'bg-amber-50 text-amber-800'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Document Inspector
                  </button>
                </>
              )}

              {user.role === 'MANAGER' && (
                <>
                  <button
                    onClick={() => setActiveTab('manager-dashboard')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'manager-dashboard'
                        ? 'bg-purple-50 text-purple-800'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Executive Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab('final-review')}
                    className={`px-3 py-2 text-sm font-semibold rounded-lg transition-colors ${
                      activeTab === 'final-review'
                        ? 'bg-purple-50 text-purple-800'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Pending Approvals
                  </button>
                </>
              )}

              {/* Utility Tools */}
              <button
                onClick={onOpenRAG}
                className="px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100/80 rounded-xl flex items-center gap-1.5 border border-indigo-200 shadow-2xs transition-all"
                title="Ask AI Policy Assistant (Privacy RAG with PII Masking)"
              >
                <Bot className="w-3.5 h-3.5 text-indigo-600" />
                <span>AI Assistant</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-extrabold border border-emerald-300">
                  DPDP
                </span>
              </button>

              <button
                onClick={onOpenCalculator}
                className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg flex items-center gap-1.5"
                title="Open EMI Calculator"
              >
                <Calculator className="w-4 h-4 text-slate-500" />
                <span>Calculator</span>
              </button>

              {(user.role === 'EMPLOYEE' || user.role === 'MANAGER') && (
                <button
                  onClick={onOpenAuditLogs}
                  className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg flex items-center gap-1.5"
                  title="View Audit Logs"
                >
                  <History className="w-4 h-4 text-slate-500" />
                  <span>Audit Logs</span>
                </button>
              )}
            </div>
          )}

          {/* Right Area: WebSocket Status, Notifications & Profile */}
          <div className="flex items-center gap-3">
            {/* Live WS Status Indicator */}
            <div 
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border bg-slate-50 border-slate-200"
              title={wsConnected ? 'Real-time WebSocket Live' : 'Reconnecting WebSocket...'}
            >
              <span className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`}></span>
              <span className="hidden sm:inline text-slate-600">{wsConnected ? 'Live' : 'Syncing'}</span>
            </div>

            {user && (
              <>
                {/* Notification Bell */}
                <button
                  onClick={onToggleNotifications}
                  className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>

                {/* 1-Click Role Switcher for Evaluators */}
                {onSwitchRole && (
                  <div className="hidden xl:flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-[11px] font-bold">
                    <span className="text-slate-400 px-1 text-[10px]">Switch:</span>
                    <button
                      type="button"
                      onClick={() => onSwitchRole('CUSTOMER')}
                      className={`px-2 py-0.5 rounded-lg transition-all ${
                        user.role === 'CUSTOMER'
                          ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Customer
                    </button>
                    <button
                      type="button"
                      onClick={() => onSwitchRole('EMPLOYEE')}
                      className={`px-2 py-0.5 rounded-lg transition-all ${
                        user.role === 'EMPLOYEE'
                          ? 'bg-white text-amber-700 shadow-2xs font-extrabold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Officer
                    </button>
                    <button
                      type="button"
                      onClick={() => onSwitchRole('MANAGER')}
                      className={`px-2 py-0.5 rounded-lg transition-all ${
                        user.role === 'MANAGER'
                          ? 'bg-white text-purple-700 shadow-2xs font-extrabold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Manager
                    </button>
                  </div>
                )}

                {/* Role Badge */}
                <span className={`hidden lg:inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-semibold border ${badge?.bg}`}>
                  {badge?.label}
                </span>

                {/* User Info & Logout */}
                <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 ring-2 ring-blue-500/20 flex items-center justify-center font-bold text-xs text-white shadow-xs">
                    {user.first_name ? user.first_name[0] : user.username[0]?.toUpperCase()}
                  </div>
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-semibold text-slate-900 leading-tight">
                      {user.full_name || user.username}
                    </p>
                    <p className="text-[11px] text-slate-500 leading-tight">
                      {user.employee_id ? `#${user.employee_id}` : user.role.toLowerCase()}
                    </p>
                  </div>
                  <button
                    onClick={onLogout}
                    className="p-1.5 ml-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>

        </div>
      </div>
    </header>
  );
}
