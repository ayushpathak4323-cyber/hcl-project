import React from 'react';
import { 
  Bell, Check, X, Shield, Clock, AlertTriangle, 
  CheckCircle2, FileText, ArrowRight
} from 'lucide-react';

export default function NotificationDrawer({ isOpen, onClose, notifications, onMarkAllRead }) {
  if (!isOpen) return null;

  const getIcon = (type) => {
    switch (type) {
      case 'LOAN_APPROVED':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'DOCUMENT_REJECTED':
      case 'EMI_OVERDUE':
      case 'LOAN_REJECTED':
        return <AlertTriangle className="w-4 h-4 text-rose-600" />;
      case 'APPLICATION_SUBMITTED':
      case 'EMPLOYEE_VERIFIED':
        return <FileText className="w-4 h-4 text-blue-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity" 
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-sm bg-white shadow-2xl border-l border-slate-200 flex flex-col">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <h2 className="font-bold text-slate-900 text-sm">Notifications</h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={onMarkAllRead}
                className="text-xs text-blue-600 hover:text-blue-800 font-semibold"
              >
                Mark all read
              </button>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {notifications.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-xs">
                <Bell className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                <p>No notifications yet.</p>
              </div>
            ) : (
              notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-3.5 rounded-2xl border transition-all text-xs space-y-1 ${
                    notif.is_read
                      ? 'bg-white border-slate-200 text-slate-600'
                      : 'bg-blue-50/60 border-blue-200 text-slate-900 font-medium'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className="shrink-0 mt-0.5">{getIcon(notif.notification_type)}</div>
                    <div className="flex-1">
                      <p className="font-bold text-slate-900 leading-tight">{notif.title}</p>
                      <p className="text-slate-600 mt-1 leading-relaxed text-[11px]">{notif.message}</p>
                      <span className="text-[10px] text-slate-400 mt-1.5 block">
                        {new Date(notif.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500">
            Push Alerts via Django Channels & WebSockets
          </div>

        </div>
      </div>
    </div>
  );
}
