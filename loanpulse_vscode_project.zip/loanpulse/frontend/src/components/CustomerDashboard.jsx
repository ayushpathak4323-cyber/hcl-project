import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, FileText, CheckCircle2, Clock, AlertTriangle, 
  DollarSign, TrendingUp, Calendar, ChevronRight, Upload, 
  FileCheck, Shield, AlertCircle, ArrowLeft, ArrowRight, 
  CreditCard, Eye, RefreshCw, Sparkles, Building, User, Bot,
  Camera, Video
} from 'lucide-react';
import { api } from '../api';
import RAGAssistantModal from './RAGAssistantModal';
import SelfieVerificationModal from './SelfieVerificationModal';

// Visual Speedometer Gauge for CIBIL Credit Score (300 to 900)
function CibilGauge({ score }) {
  const clamped = Math.max(300, Math.min(900, score || 750));
  const fraction = (clamped - 300) / 600;
  // Angle: -90 (left at 300) to +90 (right at 900)
  const angle = -90 + fraction * 180;
  const rad = (angle * Math.PI) / 180;
  // Needle length 62, pivot at (100, 95)
  const nx = 100 + 62 * Math.sin(rad);
  const ny = 95 - 62 * Math.cos(rad);

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 200 115" className="w-44 sm:w-52 overflow-visible">
        <defs>
          <linearGradient id="cibilSpeedoGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#f43f5e" />
            <stop offset="35%" stopColor="#f59e0b" />
            <stop offset="68%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#10b981" />
          </linearGradient>
        </defs>
        {/* Gray Background Track */}
        <path
          d="M 20 95 A 80 80 0 0 1 180 95"
          fill="none"
          stroke="#e2e8f0"
          strokeWidth="14"
          strokeLinecap="round"
        />
        {/* Dynamic Colored Track */}
        <path
          d="M 20 95 A 80 80 0 0 1 180 95"
          fill="none"
          stroke="url(#cibilSpeedoGrad)"
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray="251.32"
          strokeDashoffset={251.32 * (1 - fraction)}
          className="transition-all duration-700 ease-out"
        />
        {/* Dynamic Needle */}
        <line
          x1="100"
          y1="95"
          x2={nx}
          y2={ny}
          stroke="#0f172a"
          strokeWidth="3.5"
          strokeLinecap="round"
          className="transition-all duration-700 ease-out"
        />
        <circle cx="100" cy="95" r="7" fill="#0f172a" />
        <circle cx="100" cy="95" r="3" fill="#ffffff" />
        {/* Scale Numbers */}
        <text x="18" y="112" fontSize="9" fill="#94a3b8" fontWeight="700">300</text>
        <text x="92" y="28" fontSize="9" fill="#94a3b8" fontWeight="700">600</text>
        <text x="168" y="112" fontSize="9" fill="#94a3b8" fontWeight="700">900</text>
      </svg>
    </div>
  );
}

// Visual Principal vs Total Interest Donut Breakdown
function EMIDonutChart({ principal, totalInterest }) {
  const p = Number(principal) || 1;
  const i = Number(totalInterest) || 0;
  const total = p + i;
  const pPct = Math.max(1, Math.min(99, Math.round((p / total) * 100)));
  const iPct = 100 - pPct;

  const circ = 226.2;
  const pDash = (pPct / 100) * circ;
  const iDash = circ - pDash;

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-900/60 p-3.5 rounded-xl border border-white/10">
      <div className="relative w-20 h-20 shrink-0">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90 transform">
          <circle
            cx="50"
            cy="50"
            r="36"
            fill="transparent"
            stroke="#3b82f6"
            strokeWidth="14"
            strokeDasharray={`${pDash} ${circ}`}
            strokeDashoffset="0"
            className="transition-all duration-500"
          />
          <circle
            cx="50"
            cy="50"
            r="36"
            fill="transparent"
            stroke="#f59e0b"
            strokeWidth="14"
            strokeDasharray={`${iDash} ${circ}`}
            strokeDashoffset={`-${pDash}`}
            className="transition-all duration-500"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-[10px] font-bold text-slate-400">Principal</span>
          <span className="text-xs font-black text-white">{pPct}%</span>
        </div>
      </div>
      <div className="flex-1 w-full space-y-1.5 text-xs">
        <div className="flex items-center justify-between pb-1 border-b border-white/10">
          <span className="flex items-center gap-1.5 text-blue-300 font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            Principal ({pPct}%)
          </span>
          <span className="font-bold text-white">₹{p.toLocaleString('en-IN')}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-amber-300 font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            Interest ({iPct}%)
          </span>
          <span className="font-bold text-white">₹{i.toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>
  );
}

export default function CustomerDashboard({ user, activeTab, setActiveTab, onRefreshBadge, onOpenRAG }) {
  const [profile, setProfile] = useState(null);
  const [products, setProducts] = useState([]);
  const [applications, setApplications] = useState([]);
  const [activeLoans, setActiveLoans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState(null);

  // RAG & Bureau Pull State
  const [isRAGModalOpen, setIsRAGModalOpen] = useState(false);
  const [bureauPulling, setBureauPulling] = useState(false);
  const [bureauPulled, setBureauPulled] = useState(false);
  const [isSelfieModalOpen, setIsSelfieModalOpen] = useState(false);

  const handleSelfieVerified = (selfieData) => {
    setFormData((prev) => ({
      ...prev,
      uploadedDocs: [
        ...prev.uploadedDocs.filter((d) => d.type !== 'SELFIE'),
        {
          id: selfieData.id,
          type: 'SELFIE',
          file_name: selfieData.file_name,
          file_url: selfieData.file_url,
          status: 'AUTO_VERIFIED',
          confidence: selfieData.confidence || 96.8,
          detected_type: 'SELFIE',
          is_match: true,
          message: 'Live Biometric Selfie & Liveness Verified',
          preview: selfieData.preview,
        },
      ],
    }));
  };

  // Multi-step Application Wizard State
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Personal
    full_name: user?.full_name || '',
    dob: '1994-06-15',
    phone: user?.phone || '9876543210',
    email: user?.email || '',
    address: 'Flat 402, Skyline Towers, Sector 62',
    city: 'Noida',
    state: 'Uttar Pradesh',
    pincode: '201309',
    employment_status: 'Salaried',
    cibil_score: user?.cibil_score || 780,

    // Step 2: Financial
    monthly_income: '85000',
    employment_type: 'Full-time',
    company_name: 'Infosys Technologies Ltd',
    existing_loans: '1',
    existing_monthly_emi: '7500',
    bank_account_number: '918020045812901',
    bank_ifsc: 'HDFC0001024',
    loan_purpose: 'Home Improvement & Technology Gadgets',

    // Step 3: Loan Details
    loan_product_id: '',
    requested_amount: 250000,
    tenure_months: 24,

    // Step 4: Documents
    uploadedDocs: [], // { id, type, file_name, status, is_match, message, confidence }
  });

  const handleSimulateBureauPull = () => {
    setBureauPulling(true);
    setTimeout(() => {
      const simulatedScores = [765, 780, 810, 792, 775];
      const fetchedScore = simulatedScores[Math.floor(Math.random() * simulatedScores.length)];
      setFormData((prev) => ({ ...prev, cibil_score: fetchedScore }));
      setBureauPulling(false);
      setBureauPulled(true);
    }, 750);
  };

  const getCibilTier = (score) => {
    if (score >= 750) return { label: 'Prime / Tier 1 (Fast-Track)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200', desc: 'Pre-qualified for lowest interest margins and automated approval.' };
    if (score >= 700) return { label: 'Good / Standard Tier', color: 'text-blue-700 bg-blue-50 border-blue-200', desc: 'Standard lending terms, high approval likelihood.' };
    if (score >= 650) return { label: 'Fair / Scrutiny Tier', color: 'text-amber-700 bg-amber-50 border-amber-200', desc: 'May require guarantor or higher income stability proof.' };
    return { label: 'Sub-prime / High Risk', color: 'text-rose-700 bg-rose-50 border-rose-200', desc: 'Elevated risk weighting, manual credit committee review required.' };
  };

  // Dynamic EMI preview
  const [emiPreview, setEmiPreview] = useState({
    calculated_emi: 0,
    total_interest: 0,
    total_repayment: 0,
  });

  // OCR Upload State for Step 4
  const [uploadDocType, setUploadDocType] = useState('AADHAAR');
  const [uploadFile, setUploadFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState('');
  const [submittingApp, setSubmittingApp] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [prodsData, appsData, loansData] = await Promise.all([
        api.getLoanProducts(),
        api.getCustomerApplications(),
        api.getCustomerActiveLoans(),
      ]);
      setProducts(prodsData);
      if (prodsData.length > 0 && !formData.loan_product_id) {
        setFormData((prev) => ({ ...prev, loan_product_id: prodsData[0].id }));
      }
      setApplications(appsData);
      setActiveLoans(loansData);
    } catch (err) {
      console.error('Failed to load customer data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Recalculate EMI when amount, tenure or product changes
  useEffect(() => {
    const selectedProd = products.find((p) => p.id === Number(formData.loan_product_id)) || products[0];
    const rate = selectedProd ? selectedProd.interest_rate_min : 10.5;

    api.calculateEMI(formData.requested_amount, rate, formData.tenure_months)
      .then((res) => {
        setEmiPreview(res);
      })
      .catch((err) => console.error(err));
  }, [formData.requested_amount, formData.tenure_months, formData.loan_product_id, products]);

  // Handle OCR Document Upload & Validation
  const handleUploadDocument = async (e) => {
    e.preventDefault();
    if (!uploadFile) {
      setUploadError('Please select a file to upload.');
      return;
    }

    setUploading(true);
    setUploadError('');
    setUploadSuccess('');

    const form = new FormData();
    form.append('file', uploadFile);
    form.append('document_type', uploadDocType);

    try {
      const res = await api.uploadDocument(form);
      setUploadSuccess(`✓ ${res.message}`);
      setFormData((prev) => ({
        ...prev,
        uploadedDocs: [
          ...prev.uploadedDocs.filter((d) => d.type !== uploadDocType),
          {
            id: res.document.id,
            type: uploadDocType,
            file_name: res.document.file_name,
            status: res.document.verification_status,
            confidence: res.confidence,
            detected_type: res.detected_type,
            is_match: res.is_match,
            message: res.message,
          },
        ],
      }));
      setUploadFile(null);
    } catch (err) {
      console.error(err);
      const data = err.data || {};
      setUploadError(
        data.message ||
        data.error ||
        `The uploaded document does not appear to be an ${uploadDocType} document. Please upload the correct document.`
      );
    } finally {
      setUploading(false);
    }
  };

  // Helper: Fast simulate uploading pre-generated sample docs
  const handleSimulateSampleDoc = async (docType, isCorrect = true) => {
    setUploading(true);
    setUploadError('');
    setUploadSuccess('');

    // Create a mock blob with text matching the expected document format
    let content = '';
    let fname = '';
    if (docType === 'AADHAAR') {
      fname = 'Aadhaar_Card_Verified.pdf';
      content = isCorrect
        ? 'Unique Identification Authority of India Government of India Aadhaar 5412 8921 4410 Rahul Sharma DOB 15/06/1994'
        : 'Chocolate Cake Recipe 2 cups flour sugar milk cocoa powder';
    } else if (docType === 'PAN') {
      fname = 'PAN_Card_Verified.pdf';
      content = isCorrect
        ? 'INCOME TAX DEPARTMENT Permanent Account Number ABCDE1234F Govt of India Rahul Sharma'
        : 'Random notes recipe book item 1234';
    } else if (docType === 'SALARY_SLIP') {
      fname = 'Salary_Slip_August.pdf';
      content = isCorrect
        ? 'Salary Slip Month August 2026 Infosys Technologies Basic Pay 45000 HRA 20000 Net Salary 85000'
        : 'Unrelated travel itinerary booking';
    } else if (docType === 'BANK_STATEMENT') {
      fname = 'Bank_Statement_HDFC.pdf';
      content = isCorrect
        ? 'HDFC Bank Account Statement Account Number 918020045812901 IFSC HDFC0001024 Closing Balance 112000 Credit Debit'
        : 'Utility warranty document';
    }

    const blob = new Blob([content], { type: 'application/pdf' });
    const file = new File([blob], fname, { type: 'application/pdf' });

    const form = new FormData();
    form.append('file', file);
    form.append('document_type', docType);

    try {
      const res = await api.uploadDocument(form);
      setUploadSuccess(`✓ ${res.message}`);
      setFormData((prev) => ({
        ...prev,
        uploadedDocs: [
          ...prev.uploadedDocs.filter((d) => d.type !== docType),
          {
            id: res.document.id,
            type: docType,
            file_name: res.document.file_name,
            status: res.document.verification_status,
            confidence: res.confidence,
            detected_type: res.detected_type,
            is_match: res.is_match,
            message: res.message,
          },
        ],
      }));
    } catch (err) {
      console.error(err);
      const data = err.data || {};
      setUploadError(
        data.message ||
        `The uploaded document does not appear to be an ${docType} document. Please upload the correct document.`
      );
    } finally {
      setUploading(false);
    }
  };

  // Submit Final Application
  const handleSubmitApplication = async () => {
    setSubmittingApp(true);
    try {
      const payload = {
        ...formData,
        document_ids: formData.uploadedDocs.map((d) => d.id),
      };
      const createdApp = await api.submitLoanApplication(payload);
      await loadData();
      if (onRefreshBadge) onRefreshBadge();
      setSelectedApp(createdApp);
      setStep(1);
      setActiveTab('applications');
    } catch (err) {
      console.error('Failed to submit application:', err);
      alert('Application submission failed. Please ensure required documents are uploaded.');
    } finally {
      setSubmittingApp(false);
    }
  };

  // Repayment simulation
  const handlePayEMI = async (emiId) => {
    try {
      const res = await api.payEMI(emiId);
      await loadData();
      if (onRefreshBadge) onRefreshBadge();
      alert(`Payment of ₹${res.emi.emi_amount} Successful! Transaction Ref: ${res.transaction_reference}`);
    } catch (err) {
      console.error(err);
      alert(err.data?.error || 'Payment failed.');
    }
  };

  // Overdue simulation
  const handleSimulateOverdue = async (emiId) => {
    try {
      await api.simulateOverdue(emiId);
      await loadData();
      if (onRefreshBadge) onRefreshBadge();
      alert('Installment marked as OVERDUE. Alert notification broadcasted to Customer.');
    } catch (err) {
      console.error(err);
      alert('Failed to simulate overdue.');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'EMPLOYEE_VERIFIED':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'UNDER_REVIEW':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'SUBMITTED':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'REJECTED':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="px-3 py-1 rounded-full bg-blue-500/30 text-blue-200 text-xs font-semibold uppercase tracking-wider border border-blue-400/30">
            Customer Self-Service Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-3">
            Welcome back, {user?.full_name || 'Borrower'}
          </h1>
          <p className="mt-2 text-sm text-blue-100/90 leading-relaxed">
            Apply for pre-approved loans with real-time OCR document verification, transparent risk assessment, and automated instant credit scoring.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('apply')}
              className="px-4 py-2.5 rounded-xl bg-white text-blue-900 text-xs font-bold shadow-md hover:bg-blue-50 transition-all flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4 text-blue-600" />
              <span>Apply for New Loan</span>
            </button>
            <button
              onClick={() => setActiveTab('active-loans')}
              className="px-4 py-2.5 rounded-xl bg-blue-700/50 hover:bg-blue-700/70 border border-blue-400/30 text-white text-xs font-bold transition-all flex items-center gap-2"
            >
              <CreditCard className="w-4 h-4 text-blue-300" />
              <span>Active Repayment Schedule</span>
            </button>
            <button
              onClick={onOpenRAG || (() => setIsRAGModalOpen(true))}
              className="px-4 py-2.5 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-300/40 text-white text-xs font-bold transition-all flex items-center gap-2 shadow-sm"
              title="Query loan underwriting policies with automatic PII sanitization"
            >
              <Bot className="w-4 h-4 text-indigo-300" />
              <span>Ask AI Policy Assistant (Privacy RAG)</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold border border-emerald-400/30">
                DPDP Safe
              </span>
            </button>
          </div>
        </div>

        {/* Decorative background element */}
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">My Applications</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 mt-2">{applications.length}</p>
          <p className="text-xs text-slate-500 mt-1">Total loan requests filed</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Active Loans</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 mt-2">{activeLoans.length}</p>
          <p className="text-xs text-slate-500 mt-1">Disbursed & active</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Total Borrowed</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 mt-2">
            ₹{activeLoans.reduce((acc, l) => acc + Number(l.approved_amount), 0).toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-slate-500 mt-1">Cumulative principal</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Next EMI Due</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-slate-900 mt-2">
            {activeLoans[0]?.emi_schedules?.find((e) => e.status === 'PENDING')
              ? `₹${Number(activeLoans[0].monthly_emi).toLocaleString('en-IN')}`
              : '₹0'}
          </p>
          <p className="text-xs text-slate-500 mt-1">Auto-debit active</p>
        </div>
      </div>

      {/* TAB 1: DASHBOARD HOME & RECENT ACTIVITY */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 card-shadow">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">Recent Loan Applications</h2>
                <p className="text-xs text-slate-500">Track current status of your submitted applications</p>
              </div>
              <button
                onClick={() => setActiveTab('apply')}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                <span>New Application</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {applications.length === 0 ? (
              <div className="text-center py-10 text-slate-400">
                <FileText className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                <p className="text-sm">You haven't submitted any loan applications yet.</p>
                <button
                  onClick={() => setActiveTab('apply')}
                  className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
                >
                  Start Loan Application
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 uppercase border-y border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Application #</th>
                      <th className="py-3 px-4">Product</th>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Tenure</th>
                      <th className="py-3 px-4">Monthly EMI</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {applications.slice(0, 5).map((app) => (
                      <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-blue-700">{app.application_number}</td>
                        <td className="py-3 px-4 font-medium text-slate-800">{app.loan_product_name}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">₹{Number(app.requested_amount).toLocaleString('en-IN')}</td>
                        <td className="py-3 px-4 text-slate-600">{app.tenure_months} mos</td>
                        <td className="py-3 px-4 font-semibold text-slate-800">₹{Number(app.calculated_emi).toLocaleString('en-IN')}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded-full font-semibold text-[11px] border ${getStatusColor(app.status)}`}>
                            {app.status_display || app.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={async () => {
                              const detail = await api.getApplicationDetail(app.id);
                              setSelectedApp(detail);
                            }}
                            className="p-1 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50"
                            title="View Application Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: MULTI-STEP LOAN APPLICATION WIZARD */}
      {activeTab === 'apply' && (
        <div className="bg-white rounded-3xl border border-slate-200 card-shadow overflow-hidden">
          
          {/* Progress Indicator */}
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-4">
            <div className="flex items-center justify-between max-w-3xl mx-auto">
              {[
                { num: 1, label: 'Personal Details' },
                { num: 2, label: 'Financial Info' },
                { num: 3, label: 'Loan & EMI' },
                { num: 4, label: 'OCR Validation' },
                { num: 5, label: 'Review & Submit' },
              ].map((s) => (
                <div key={s.num} className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      step === s.num
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                        : step > s.num
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {step > s.num ? '✓' : s.num}
                  </div>
                  <span className={`text-xs font-semibold hidden md:inline ${step === s.num ? 'text-blue-900' : 'text-slate-500'}`}>
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 sm:p-8 max-w-3xl mx-auto">
            
            {/* STEP 1: PERSONAL DETAILS */}
            {step === 1 && (
              <div className="space-y-4 animate-fade-in">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Step 1: Personal Information</h2>
                  <p className="text-xs text-slate-500">Provide your verified KYC demographic details.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Full Name (as per PAN)</label>
                    <input
                      type="text"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Date of Birth</label>
                    <input
                      type="date"
                      value={formData.dob}
                      onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Residential Address</label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">City</label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Pincode</label>
                    <input
                      type="text"
                      value={formData.pincode}
                      onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  {/* CIBIL Score & Bureau Rating Card */}
                  <div className="sm:col-span-2 mt-2 p-5 rounded-2xl bg-gradient-to-br from-blue-50/90 via-indigo-50/70 to-slate-50 border border-blue-200 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-blue-200/70">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-black text-xs shadow-sm shadow-blue-500/20">
                          CB
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold text-slate-900">CIBIL / Credit Bureau Rating</h3>
                            <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                              Range: 300 - 900
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            Influences automated risk tiering, interest concession & eligibility.
                          </p>
                        </div>
                      </div>

                      {/* Bureau Pull Simulation Button */}
                      <button
                        type="button"
                        onClick={handleSimulateBureauPull}
                        disabled={bureauPulling}
                        className="px-3.5 py-2 rounded-xl bg-white hover:bg-blue-50 border border-blue-300 text-blue-800 text-xs font-bold transition-all flex items-center gap-2 shadow-xs shrink-0"
                        title="Simulate real-time bureau pull from TransUnion CIBIL CIR service"
                      >
                        {bureauPulling ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
                            <span>Pulling Bureau CIR...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                            <span>Fetch Bureau CIBIL Score</span>
                          </>
                        )}
                      </button>
                    </div>

                    {bureauPulled && (
                      <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-800 flex items-center gap-2 animate-fade-in">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>
                          <strong>Bureau Verified:</strong> CIBIL CIR record pulled successfully via banking gateway simulation.
                        </span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-5 pt-1 items-center">
                      {/* Left: Speedometer Gauge */}
                      <div className="md:col-span-5 flex flex-col items-center justify-center p-3.5 rounded-2xl bg-white border border-blue-100 shadow-2xs">
                        <CibilGauge score={formData.cibil_score} />
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-2xl font-black text-slate-900 font-mono tracking-tight">
                            {formData.cibil_score}
                          </span>
                          <span className="text-xs text-slate-400 font-medium">/ 900</span>
                          <span className={`text-[11px] px-2 py-0.5 rounded-full font-extrabold border ${getCibilTier(formData.cibil_score).color}`}>
                            {formData.cibil_score >= 750 ? 'Prime' : formData.cibil_score >= 700 ? 'Good' : 'Sub-prime'}
                          </span>
                        </div>
                      </div>

                      {/* Right: Controls & Presets */}
                      <div className="md:col-span-7 space-y-3">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-700">Adjust Bureau Score</span>
                          <span className="text-[11px] text-slate-400">Drag slider or pick a preset</span>
                        </div>

                        <input
                          type="range"
                          min="300"
                          max="900"
                          step="5"
                          value={formData.cibil_score}
                          onChange={(e) => setFormData({ ...formData, cibil_score: Number(e.target.value) })}
                          className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                        />

                        {/* Presets */}
                        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                          <span className="text-[10px] uppercase font-bold text-slate-400 mr-1">Presets:</span>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, cibil_score: 590 })}
                            className="px-2 py-0.5 rounded-md bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-bold"
                          >
                            590 (Poor)
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, cibil_score: 680 })}
                            className="px-2 py-0.5 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 text-[10px] font-bold"
                          >
                            680 (Fair)
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, cibil_score: 755 })}
                            className="px-2 py-0.5 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-[10px] font-bold"
                          >
                            755 (Good)
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, cibil_score: 830 })}
                            className="px-2 py-0.5 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-[10px] font-bold"
                          >
                            830 (Prime)
                          </button>
                        </div>

                        {/* Tier Summary Card */}
                        <div className={`p-3 rounded-xl border ${getCibilTier(formData.cibil_score).color}`}>
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-extrabold uppercase tracking-wider">Assessment Status</span>
                            <span className="text-xs font-bold">{getCibilTier(formData.cibil_score).label}</span>
                          </div>
                          <p className="text-[11px] mt-1 opacity-90 leading-tight">
                            {getCibilTier(formData.cibil_score).desc}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 flex justify-end">
                  <button
                    onClick={() => setStep(2)}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20"
                  >
                    <span>Proceed to Financial Details</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: FINANCIAL DETAILS */}
            {step === 2 && (
              <div className="space-y-4 animate-fade-in">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Step 2: Financial Information</h2>
                  <p className="text-xs text-slate-500">Required for transparent credit risk score computation.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Monthly Net Income (₹)</label>
                    <input
                      type="number"
                      value={formData.monthly_income}
                      onChange={(e) => setFormData({ ...formData, monthly_income: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Employment Type</label>
                    <select
                      value={formData.employment_type}
                      onChange={(e) => setFormData({ ...formData, employment_type: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      <option value="Full-time">Salaried (Full-time)</option>
                      <option value="Self-employed">Self-employed / Business</option>
                      <option value="Contract">Contract / Consultant</option>
                      <option value="Part-time">Part-time</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Company / Organization</label>
                    <input
                      type="text"
                      value={formData.company_name}
                      onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Existing Active Loans Count</label>
                    <input
                      type="number"
                      value={formData.existing_loans}
                      onChange={(e) => setFormData({ ...formData, existing_loans: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Existing Monthly EMI Outflow (₹)</label>
                    <input
                      type="number"
                      value={formData.existing_monthly_emi}
                      onChange={(e) => setFormData({ ...formData, existing_monthly_emi: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Primary Salary Bank Account</label>
                    <input
                      type="text"
                      value={formData.bank_account_number}
                      onChange={(e) => setFormData({ ...formData, bank_account_number: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Loan Purpose</label>
                    <input
                      type="text"
                      value={formData.loan_purpose}
                      onChange={(e) => setFormData({ ...formData, loan_purpose: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl"
                      placeholder="e.g. Higher Education, Renovation, Vehicle Purchase"
                    />
                  </div>
                </div>

                <div className="pt-6 flex justify-between">
                  <button
                    onClick={() => setStep(1)}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20"
                  >
                    <span>Proceed to Loan Details</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: LOAN DETAILS & AUTOMATIC EMI CALCULATION */}
            {step === 3 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Step 3: Loan Details & Reducing-Balance EMI</h2>
                  <p className="text-xs text-slate-500">Configure loan amount, tenure, and examine automated calculations.</p>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-2">Select Loan Product</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {products.map((prod) => (
                      <div
                        key={prod.id}
                        onClick={() => setFormData({ ...formData, loan_product_id: prod.id })}
                        className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                          formData.loan_product_id === prod.id
                            ? 'border-blue-600 bg-blue-50/60 shadow-sm'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-slate-900">{prod.name}</span>
                          <span className="text-[11px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full">
                            {prod.interest_rate_min}% p.a.
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{prod.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Amount Slider */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-bold uppercase text-slate-700">Requested Loan Amount</label>
                    <span className="text-base font-extrabold text-blue-700">
                      ₹{Number(formData.requested_amount).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="50000"
                    max="1500000"
                    step="25000"
                    value={formData.requested_amount}
                    onChange={(e) => setFormData({ ...formData, requested_amount: Number(e.target.value) })}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400 mt-0.5">
                    <span>₹50,000</span>
                    <span>₹15,00,000</span>
                  </div>
                </div>

                {/* Tenure Slider */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-bold uppercase text-slate-700">Repayment Tenure</label>
                    <span className="text-base font-extrabold text-blue-700">{formData.tenure_months} Months</span>
                  </div>
                  <input
                    type="range"
                    min="6"
                    max="60"
                    step="6"
                    value={formData.tenure_months}
                    onChange={(e) => setFormData({ ...formData, tenure_months: Number(e.target.value) })}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400 mt-0.5">
                    <span>6 Months</span>
                    <span>60 Months</span>
                  </div>
                </div>

                {/* Automated Banking Calculation Box */}
                <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 text-white shadow-2xl border border-white/10 space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b border-white/10">
                    <div>
                      <span className="text-xs font-semibold text-blue-300 uppercase tracking-wider">
                        Monthly Reducing EMI
                      </span>
                      <p className="text-xs text-slate-400 mt-0.5">Calculated using institutional compounding formula</p>
                    </div>
                    <div className="text-right">
                      <span className="text-3xl font-black text-white font-mono tracking-tight">
                        ₹{Number(emiPreview.calculated_emi).toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs text-blue-300 font-medium block">/ month</span>
                    </div>
                  </div>

                  {/* Donut Chart Component */}
                  <EMIDonutChart principal={formData.requested_amount} totalInterest={emiPreview.total_interest} />

                  <div className="grid grid-cols-3 gap-3 pt-2 text-center text-xs">
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[11px] text-slate-400">Total Interest</p>
                      <p className="font-bold text-amber-300 text-sm mt-0.5">₹{Number(emiPreview.total_interest).toLocaleString('en-IN')}</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[11px] text-slate-400">Total Repayment</p>
                      <p className="font-bold text-white text-sm mt-0.5">₹{Number(emiPreview.total_repayment).toLocaleString('en-IN')}</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[11px] text-slate-400">Estimated DTI</p>
                      <p className="font-bold text-emerald-400 text-sm mt-0.5">
                        {((Number(emiPreview.calculated_emi) + Number(formData.existing_monthly_emi)) / (Number(formData.monthly_income) || 1) * 100).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setStep(2)}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    onClick={() => setStep(4)}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20"
                  >
                    <span>Proceed to Document Verification</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: DOCUMENT UPLOAD & LIVE OCR VALIDATION */}
            {step === 4 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900">Step 4: Document Upload & Live OCR Validation</h2>
                    <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                      OCR Engine Active
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    The system inspects uploaded documents using OCR. If the document does not match the selected type, it will be automatically rejected.
                  </p>
                </div>

                {/* Upload Form Box */}
                <form onSubmit={handleUploadDocument} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                        Select Document Type to Upload
                      </label>
                      <select
                        value={uploadDocType}
                        onChange={(e) => setUploadDocType(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl font-semibold text-slate-800"
                      >
                        <option value="AADHAAR">Aadhaar Card (UIDAI)</option>
                        <option value="PAN">PAN Card (Income Tax Dept)</option>
                        <option value="SELFIE">Live Video-KYC Selfie / Portrait</option>
                        <option value="SALARY_SLIP">Salary Slip (Payslip)</option>
                        <option value="BANK_STATEMENT">Bank Statement</option>
                        <option value="ADDRESS_PROOF">Address Proof (Utility Bill)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                        Choose Document File (PDF or Image)
                      </label>
                      <input
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) => setUploadFile(e.target.files[0])}
                        className="w-full text-xs text-slate-600 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <button
                      type="submit"
                      disabled={uploading || !uploadFile}
                      className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm"
                    >
                      {uploading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Running OCR Extraction...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Upload & Validate with OCR</span>
                        </>
                      )}
                    </button>

                    {/* Evaluator Demo Fast Helpers */}
                    <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                      <span className="text-slate-400 font-semibold mr-1">Demo Quick OCR:</span>
                      <button
                        type="button"
                        onClick={() => handleSimulateSampleDoc('AADHAAR', true)}
                        className="px-2 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-medium"
                      >
                        + Test Valid Aadhaar
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSimulateSampleDoc('PAN', true)}
                        className="px-2 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-medium"
                      >
                        + Test Valid PAN
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSimulateSampleDoc('AADHAAR', false)}
                        className="px-2 py-1 rounded-md bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 font-medium"
                        title="Simulate uploading a wrong/unrelated document to trigger rejection"
                      >
                        ⚡ Test Rejection (Wrong File)
                      </button>
                    </div>
                  </div>

                  {/* Feedback alerts */}
                  {uploadSuccess && (
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center gap-2 animate-fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{uploadSuccess}</span>
                    </div>
                  )}

                  {uploadError && (
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 flex items-center gap-2 animate-fade-in">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{uploadError}</span>
                    </div>
                  )}
                </form>

                {/* Video-KYC Live Selfie Card */}
                {(() => {
                  const selfieDoc = formData.uploadedDocs.find((d) => d.type === 'SELFIE');
                  return (
                    <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/80 via-blue-50/70 to-slate-50 border border-indigo-200 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-indigo-200/60">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
                            <Camera className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="text-sm font-bold text-slate-900">
                                Video-KYC: Live Selfie & Biometric Verification
                              </h3>
                              <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-extrabold border border-indigo-300">
                                RBI V-CIP
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500">
                              Liveness detection & facial match against uploaded Aadhaar / PAN card photo.
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setIsSelfieModalOpen(true)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-xs shrink-0 ${
                            selfieDoc
                              ? 'bg-white hover:bg-slate-50 border border-slate-300 text-slate-700'
                              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/20'
                          }`}
                        >
                          <Camera className="w-3.5 h-3.5" />
                          <span>{selfieDoc ? 'Retake Video-KYC Selfie' : 'Capture Live Selfie'}</span>
                        </button>
                      </div>

                      {selfieDoc ? (
                        <div className="flex flex-col sm:flex-row items-center gap-4 p-3.5 rounded-xl bg-white border border-emerald-200 shadow-2xs">
                          {selfieDoc.preview ? (
                            <img
                              src={selfieDoc.preview}
                              alt="Verified Selfie"
                              className="w-16 h-16 rounded-xl object-cover border-2 border-emerald-500 shrink-0 shadow-xs"
                            />
                          ) : (
                            <div className="w-16 h-16 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                              KYC Photo
                            </div>
                          )}
                          <div className="flex-1 space-y-1 text-xs">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-slate-900">Live Selfie Biometrics Verified</span>
                              <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-extrabold border border-emerald-200 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Anti-Spoofing PASS
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500">
                              Facial landmarks successfully matched with identity dossier photo.
                            </p>
                            <div className="flex items-center gap-4 text-[11px] pt-0.5">
                              <span className="text-slate-600 font-medium">
                                Liveness Score: <strong className="text-emerald-700 font-bold">98.4%</strong>
                              </span>
                              <span className="text-slate-600 font-medium">
                                ID Match: <strong className="text-emerald-700 font-bold">{selfieDoc.confidence}%</strong>
                              </span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="p-3.5 rounded-xl bg-white/80 border border-dashed border-indigo-200 text-xs text-indigo-900 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5">
                            <Shield className="w-5 h-5 text-indigo-600 shrink-0" />
                            <span className="text-[11px] text-slate-600">
                              No live selfie captured yet. Click <strong>"Capture Live Selfie"</strong> to start webcam or simulate a verified Video-KYC portrait.
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setIsSelfieModalOpen(true)}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline shrink-0"
                          >
                            Start Capture →
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Uploaded Documents List */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    Uploaded Documents Status ({formData.uploadedDocs.length})
                  </h3>

                  {formData.uploadedDocs.length === 0 ? (
                    <div className="p-4 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-400">
                      No documents verified yet. Upload at least Aadhaar and PAN to proceed.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {formData.uploadedDocs.map((doc, idx) => (
                        <div
                          key={idx}
                          className="p-3.5 rounded-xl border bg-white border-slate-200 flex items-start justify-between card-shadow"
                        >
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">
                              {doc.type.replace('_', ' ')}
                            </span>
                            <p className="text-xs font-bold text-slate-900 truncate max-w-[200px]">{doc.file_name}</p>
                            <p className="text-[11px] text-slate-500">
                              OCR Confidence: <strong className="text-emerald-700">{doc.confidence}%</strong>
                            </p>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                              doc.status === 'AUTO_VERIFIED' || doc.status === 'VERIFIED'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border-rose-200'
                            }`}
                          >
                            {doc.status === 'AUTO_VERIFIED' ? 'Verified' : doc.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setStep(3)}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    onClick={() => setStep(5)}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20"
                  >
                    <span>Review Application Dossier</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 5: FINAL APPLICATION REVIEW & SUBMIT */}
            {step === 5 && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Step 5: Review & Submit Application</h2>
                  <p className="text-xs text-slate-500">
                    Review your application summary before real-time submission to loan verification officers.
                  </p>
                </div>

                <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 text-xs">
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 pb-4 border-b border-slate-200">
                    <div>
                      <p className="text-slate-400 font-medium">Applicant</p>
                      <p className="font-bold text-slate-900 mt-0.5">{formData.full_name}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">Monthly Income</p>
                      <p className="font-bold text-slate-900 mt-0.5">₹{Number(formData.monthly_income).toLocaleString('en-IN')}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">Company</p>
                      <p className="font-bold text-slate-900 mt-0.5">{formData.company_name}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">City</p>
                      <p className="font-bold text-slate-900 mt-0.5">{formData.city}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">CIBIL Bureau Score</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono font-black text-blue-900 text-sm">{formData.cibil_score}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold border ${getCibilTier(formData.cibil_score).color}`}>
                          {formData.cibil_score >= 750 ? 'Prime' : formData.cibil_score >= 700 ? 'Good' : 'Sub-prime'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-4 border-b border-slate-200">
                    <div>
                      <p className="text-slate-400 font-medium">Loan Requested</p>
                      <p className="font-bold text-blue-700 text-sm mt-0.5">
                        ₹{Number(formData.requested_amount).toLocaleString('en-IN')}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">Tenure</p>
                      <p className="font-bold text-slate-900 mt-0.5">{formData.tenure_months} Months</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">Calculated Monthly EMI</p>
                      <p className="font-bold text-slate-900 mt-0.5">
                        ₹{Number(emiPreview.calculated_emi).toLocaleString('en-IN')}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-medium">Total Interest</p>
                      <p className="font-bold text-slate-900 mt-0.5">
                        ₹{Number(emiPreview.total_interest).toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-slate-400 font-medium mb-1.5">Attached Verified KYC Documents:</p>
                    <div className="flex flex-wrap gap-2">
                      {formData.uploadedDocs.length > 0 ? (
                        formData.uploadedDocs.map((d, i) => (
                          <span key={i} className="px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-800 font-medium text-[11px] flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            {d.type}: {d.file_name}
                          </span>
                        ))
                      ) : (
                        <span className="text-amber-600 font-semibold">
                          ⚠️ No documents attached. You can still submit and attach later.
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-start gap-2.5">
                  <Shield className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold">Real-time Notification Trigger:</strong>
                    <p className="mt-0.5 text-blue-800">
                      Upon clicking "Submit Loan Application", an automated preliminary credit risk assessment will be performed, and loan officers will immediately receive an instant WebSocket notification on their active dashboard.
                    </p>
                  </div>
                </div>

                <div className="pt-4 flex justify-between">
                  <button
                    onClick={() => setStep(4)}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    onClick={handleSubmitApplication}
                    disabled={submittingApp}
                    className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/20"
                  >
                    {submittingApp ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Submitting to LoanPulse Network...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Submit Loan Application</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* TAB 3: MY APPLICATIONS */}
      {activeTab === 'applications' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 card-shadow">
            <h2 className="text-base font-bold text-slate-900 mb-1">Application Lifecycle Tracking</h2>
            <p className="text-xs text-slate-500 mb-6">Track review progress from Submission to Verification and Final Disbursement</p>

            <div className="space-y-4">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className="p-5 rounded-2xl border border-slate-200 hover:border-slate-300 bg-white transition-all card-shadow space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm text-blue-700">#{app.application_number}</span>
                        <span className="font-semibold text-xs text-slate-900">• {app.loan_product_name}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">Applied on {new Date(app.created_at).toLocaleDateString()}</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getStatusColor(app.status)}`}>
                        {app.status_display || app.status}
                      </span>
                      <button
                        onClick={async () => {
                          const detail = await api.getApplicationDetail(app.id);
                          setSelectedApp(detail);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold"
                      >
                        Inspect Dossier
                      </button>
                    </div>
                  </div>

                  {/* Visual Status Stepper */}
                  <div className="grid grid-cols-4 gap-2 text-center text-xs pt-1">
                    {[
                      { key: 'SUBMITTED', label: '1. Submitted' },
                      { key: 'UNDER_REVIEW', label: '2. Under Review' },
                      { key: 'EMPLOYEE_VERIFIED', label: '3. Officer Verified' },
                      { key: 'APPROVED', label: '4. Disbursed' },
                    ].map((stepItem, idx) => {
                      const isComplete =
                        (stepItem.key === 'SUBMITTED' && ['SUBMITTED', 'UNDER_REVIEW', 'EMPLOYEE_VERIFIED', 'APPROVED'].includes(app.status)) ||
                        (stepItem.key === 'UNDER_REVIEW' && ['UNDER_REVIEW', 'EMPLOYEE_VERIFIED', 'APPROVED'].includes(app.status)) ||
                        (stepItem.key === 'EMPLOYEE_VERIFIED' && ['EMPLOYEE_VERIFIED', 'APPROVED'].includes(app.status)) ||
                        (stepItem.key === 'APPROVED' && app.status === 'APPROVED');

                      return (
                        <div key={idx} className="space-y-1">
                          <div className={`h-1.5 rounded-full ${isComplete ? 'bg-emerald-500' : 'bg-slate-200'}`} />
                          <span className={`text-[10px] font-semibold ${isComplete ? 'text-slate-800' : 'text-slate-400'}`}>
                            {stepItem.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ACTIVE LOANS & REPAYMENT SCHEDULE */}
      {activeTab === 'active-loans' && (
        <div className="space-y-6">
          {activeLoans.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400 card-shadow">
              <CreditCard className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <h3 className="font-bold text-slate-700 text-sm">No Active Disbursed Loans</h3>
              <p className="text-xs text-slate-500 mt-1">Once a loan application is approved by the manager, it will appear here.</p>
            </div>
          ) : (
            activeLoans.map((loan) => (
              <div key={loan.id} className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 card-shadow space-y-6">
                
                {/* Loan Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
                      Status: {loan.status}
                    </span>
                    <h2 className="text-xl font-extrabold text-slate-900 mt-2 font-mono">
                      Loan #{loan.loan_account_number}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Disbursed on {loan.disbursement_date} • Application #{loan.application_number}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs">
                    <div className="text-right">
                      <span className="text-slate-400">Approved Principal</span>
                      <p className="text-lg font-extrabold text-slate-900">
                        ₹{Number(loan.approved_amount).toLocaleString('en-IN')}
                      </p>
                    </div>
                    <div className="text-right pl-4 border-l border-slate-200">
                      <span className="text-slate-400">Monthly EMI</span>
                      <p className="text-lg font-extrabold text-blue-700">
                        ₹{Number(loan.monthly_emi).toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Progress Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500">Paid EMIs</span>
                    <p className="text-base font-extrabold text-emerald-700 mt-0.5">
                      {loan.paid_emis_count} of {loan.tenure_months}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Total Paid Amount</span>
                    <p className="text-base font-extrabold text-slate-900 mt-0.5">
                      ₹{Number(loan.total_paid_amount || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Remaining Installments</span>
                    <p className="text-base font-extrabold text-slate-900 mt-0.5">
                      {loan.remaining_emis_count} EMIs
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Interest Rate</span>
                    <p className="text-base font-extrabold text-slate-900 mt-0.5">
                      {loan.interest_rate}% p.a.
                    </p>
                  </div>
                </div>

                {/* Amortization Table */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Amortization Repayment Schedule ({loan.emi_schedules.length} Installments)
                    </h3>
                    <span className="text-[11px] text-slate-500">
                      Simulate payment or overdue status with one click
                    </span>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">#</th>
                          <th className="py-2.5 px-3">Due Date</th>
                          <th className="py-2.5 px-3">EMI Amount</th>
                          <th className="py-2.5 px-3">Principal</th>
                          <th className="py-2.5 px-3">Interest</th>
                          <th className="py-2.5 px-3">Balance</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3 text-right">Simulated Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {loan.emi_schedules.map((emi) => (
                          <tr key={emi.id} className="hover:bg-slate-50 transition-colors">
                            <td className="py-2.5 px-3 font-bold text-slate-500">{emi.installment_number}</td>
                            <td className="py-2.5 px-3 font-medium text-slate-800">{emi.due_date}</td>
                            <td className="py-2.5 px-3 font-bold text-slate-900">
                              ₹{Number(emi.emi_amount).toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600">
                              ₹{Number(emi.principal_component).toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600">
                              ₹{Number(emi.interest_component).toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3 text-slate-700 font-mono">
                              ₹{Number(emi.remaining_principal).toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                                  emi.status === 'PAID'
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                    : emi.status === 'OVERDUE'
                                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                                    : 'bg-amber-50 text-amber-700 border-amber-200'
                                }`}
                              >
                                {emi.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              {emi.status !== 'PAID' ? (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => handlePayEMI(emi.id)}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg shadow-sm"
                                  >
                                    Pay EMI
                                  </button>
                                  <button
                                    onClick={() => handleSimulateOverdue(emi.id)}
                                    className="px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 text-[10px] font-semibold rounded-lg border border-rose-200"
                                    title="Simulate overdue status"
                                  >
                                    Set Overdue
                                  </button>
                                </div>
                              ) : (
                                <span className="text-[11px] text-slate-400 font-mono">
                                  {emi.paid_date || 'Settled'}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            ))
          )}
        </div>
      )}

      {/* APPLICATION DETAIL MODAL */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <span className="font-mono text-xs font-bold text-blue-700">#{selectedApp.application_number}</span>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">{selectedApp.loan_product_name}</h3>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Risk Assessment Snapshot */}
            {selectedApp.risk_assessment && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 uppercase">Underwriting Risk Score</span>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                    selectedApp.risk_assessment.risk_level === 'LOW' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {selectedApp.risk_assessment.score}/100 • {selectedApp.risk_assessment.risk_level} RISK
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {selectedApp.risk_assessment.recommendation_summary}
                </p>
              </div>
            )}

            {/* Document Verification Table */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-700 mb-2">Attached Documents & OCR Results</h4>
              <div className="space-y-2">
                {selectedApp.documents?.map((doc) => (
                  <div key={doc.id} className="p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-slate-900">{doc.document_type_display}</p>
                      <p className="text-[11px] text-slate-500 font-mono truncate max-w-[250px]">{doc.file_name}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {doc.verification_status_display}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Staff Remarks */}
            {(selectedApp.employee_remarks || selectedApp.manager_remarks) && (
              <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-100 text-xs space-y-1">
                {selectedApp.employee_remarks && (
                  <p><strong className="text-blue-900">Loan Officer Remarks:</strong> {selectedApp.employee_remarks}</p>
                )}
                {selectedApp.manager_remarks && (
                  <p><strong className="text-blue-900">Manager Remarks:</strong> {selectedApp.manager_remarks}</p>
                )}
              </div>
            )}

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedApp(null)}
                className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Close Dossier
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Live Selfie Video-KYC Modal */}
      <SelfieVerificationModal
        isOpen={isSelfieModalOpen}
        onClose={() => setIsSelfieModalOpen(false)}
        onSelfieVerified={handleSelfieVerified}
        currentApplicantName={formData.full_name}
      />

      {/* Fallback RAG Assistant Modal if not handled at root App level */}
      {!onOpenRAG && (
        <RAGAssistantModal
          isOpen={isRAGModalOpen}
          onClose={() => setIsRAGModalOpen(false)}
          userContext={user}
        />
      )}

    </div>
  );
}
