import React, { useState, useEffect } from 'react';
import { 
  Award, CheckCircle2, XCircle, AlertCircle, FileText, 
  Eye, Check, X, Shield, Clock, ArrowRight, DollarSign, 
  TrendingUp, RefreshCw, AlertTriangle, Layers, Calendar, 
  Sparkles, CreditCard
} from 'lucide-react';
import { api } from '../api';

export default function ManagerDashboard({ user, onRefreshBadge }) {
  const [stats, setStats] = useState({
    total_applications: 0,
    employee_verified_applications: 0,
    pending_final_review: 0,
    approved_loans: 0,
    rejected_loans: 0,
    active_loans: 0,
    total_disbursed: 0,
    overdue_loans: 0,
  });
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  // Active Review Modal Workspace
  const [selectedApp, setSelectedApp] = useState(null);
  const [managerRemarks, setManagerRemarks] = useState('');
  const [processingDecision, setProcessingDecision] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, appsData] = await Promise.all([
        api.getManagerStats(),
        api.getEmployeeApplications(''), // Load all for manager
      ]);
      setStats(statsData);
      setApplications(appsData.applications);
    } catch (err) {
      console.error('Failed to load manager dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenReview = async (appId) => {
    try {
      const detail = await api.getApplicationDetail(appId);
      setSelectedApp(detail);
      setManagerRemarks('');
    } catch (err) {
      console.error('Failed to open application review:', err);
    }
  };

  const handleDecision = async (decision) => {
    if (!managerRemarks && decision !== 'APPROVE') {
      alert('Please enter remarks explaining your decision.');
      return;
    }

    setProcessingDecision(true);
    try {
      const res = await api.submitManagerDecision(selectedApp.id, decision, managerRemarks);
      if (decision === 'APPROVE') {
        alert(`Loan Successfully Approved! Disbursed Account Number: ${res.loan.loan_account_number}. Real-time notification delivered to Borrower.`);
      } else if (decision === 'REJECT') {
        alert('Loan Application Rejected. Audit trail logged and Borrower notified.');
      } else {
        alert('Information clarification request routed to Loan Officer and Applicant.');
      }
      setSelectedApp(null);
      await loadData();
      if (onRefreshBadge) onRefreshBadge();
    } catch (err) {
      console.error('Failed to execute manager decision:', err);
      alert('Error recording decision.');
    } finally {
      setProcessingDecision(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'EMPLOYEE_VERIFIED':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'UNDER_REVIEW':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'SUBMITTED':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'REJECTED':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Executive Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 card-shadow">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-800 text-xs font-bold border border-purple-200">
              Senior Underwriter Code: {user?.employee_id || 'MGR001'}
            </span>
            <span className="text-xs text-slate-400">• Credit Committee Authorization</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            Executive Credit & Approval Center
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Final review authority for officer-verified loan applications. Sanction loan disbursements and execute credit risk governance.
          </p>
        </div>

        <button
          onClick={loadData}
          className="px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 flex items-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Portfolio</span>
        </button>
      </div>

      {/* Manager Portfolio Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <span className="text-[11px] font-bold uppercase text-purple-700">Verified by Officers</span>
          <p className="text-2xl font-extrabold text-purple-900 mt-1">{stats.employee_verified_applications}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Awaiting Manager Decision</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <span className="text-[11px] font-bold uppercase text-emerald-700">Approved Loans</span>
          <p className="text-2xl font-extrabold text-emerald-800 mt-1">{stats.approved_loans}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Disbursed to borrowers</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <span className="text-[11px] font-bold uppercase text-blue-700">Total Capital Disbursed</span>
          <p className="text-2xl font-extrabold text-blue-900 mt-1">
            ₹{Number(stats.total_disbursed).toLocaleString('en-IN')}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Active bank exposure</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <span className="text-[11px] font-bold uppercase text-rose-700">Overdue Installments</span>
          <p className="text-2xl font-extrabold text-rose-800 mt-1">{stats.overdue_loans}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Triggered late alerts</p>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 card-shadow space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Final Decision & Review Board</h2>
            <p className="text-xs text-slate-500">
              Applications requiring executive review or sanctioned disbursements
            </p>
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Application #</th>
                <th className="py-3 px-4">Applicant</th>
                <th className="py-3 px-4">Product</th>
                <th className="py-3 px-4">Sanction Amount</th>
                <th className="py-3 px-4">Tenure</th>
                <th className="py-3 px-4">Risk Rating</th>
                <th className="py-3 px-4">Workflow Status</th>
                <th className="py-3 px-4 text-right">Committee Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {applications.map((app) => (
                <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-blue-700">#{app.application_number}</td>
                  <td className="py-3 px-4 font-medium text-slate-900">{app.customer_name}</td>
                  <td className="py-3 px-4 text-slate-700">{app.loan_product_name}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">₹{Number(app.requested_amount).toLocaleString('en-IN')}</td>
                  <td className="py-3 px-4 text-slate-600">{app.tenure_months} mos</td>
                  <td className="py-3 px-4">
                    {app.risk_score ? (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        app.risk_level === 'LOW' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {app.risk_score}/100 • {app.risk_level}
                      </span>
                    ) : (
                      <span className="text-slate-400 font-mono">Pending</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded-full font-semibold text-[10px] border ${getStatusColor(app.status)}`}>
                      {app.status_display || app.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleOpenReview(app.id)}
                      className={`px-3 py-1.5 rounded-xl font-bold text-xs shadow-xs transition-all ${
                        app.status === 'EMPLOYEE_VERIFIED'
                          ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-500/20 animate-pulse'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {app.status === 'EMPLOYEE_VERIFIED' ? 'Final Review' : 'Inspect'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* FINAL REVIEW WORKSPACE MODAL */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-bold text-purple-700">#{selectedApp.application_number}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${getStatusColor(selectedApp.status)}`}>
                    {selectedApp.status_display || selectedApp.status}
                  </span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 mt-1">
                  Manager Review & Disbursement Sanction
                </h2>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Officer Verification Report Box */}
            {selectedApp.verification_report ? (
              <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-900 uppercase">
                    Loan Officer Verification Report ({selectedApp.verification_report.employee_name})
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 font-extrabold">
                    {selectedApp.verification_report.overall_recommendation.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-purple-950 font-medium">
                  Remarks: {selectedApp.verification_report.remarks}
                </p>
                <div className="flex gap-4 text-[11px] text-purple-800 pt-1">
                  <span>Risk Score Snapshot: <strong>{selectedApp.verification_report.risk_score_snapshot}/100</strong></span>
                  <span>Documents Summary: <strong>{selectedApp.verification_report.documents_summary?.verified || 0} verified</strong></span>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
                Notice: Application has not completed loan officer verification report.
              </div>
            )}

            {/* Applicant Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <span className="text-slate-400 font-medium">Applicant Name</span>
                <p className="font-extrabold text-slate-900 mt-0.5">{selectedApp.customer_name}</p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Employer / Company</span>
                <p className="font-extrabold text-slate-900 mt-0.5">{selectedApp.customer_profile?.company_name || 'N/A'}</p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Monthly Income</span>
                <p className="font-extrabold text-slate-900 mt-0.5">
                  ₹{Number(selectedApp.customer_profile?.monthly_income || 0).toLocaleString('en-IN')}
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Sanction Amount</span>
                <p className="font-extrabold text-blue-700 mt-0.5">
                  ₹{Number(selectedApp.requested_amount).toLocaleString('en-IN')}
                </p>
              </div>
            </div>

            {/* Risk Assessment Details */}
            {selectedApp.risk_assessment && (
              <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="font-bold text-blue-400">Risk Assessment Analysis</span>
                  <span className="font-mono font-bold">{selectedApp.risk_assessment.score} / 100</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {selectedApp.risk_assessment.recommendation_summary}
                </p>
              </div>
            )}

            {/* Manager Remarks & Action Controls */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Manager Decision Remarks / Discretion Notes
                </label>
                <input
                  type="text"
                  value={managerRemarks}
                  onChange={(e) => setManagerRemarks(e.target.value)}
                  placeholder="Approved within delegated authority. Disburse to borrower bank account."
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => handleDecision('REQUEST_INFO')}
                  disabled={processingDecision}
                  className="px-4 py-2.5 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200 font-bold text-xs"
                >
                  Request More Info
                </button>

                <button
                  type="button"
                  onClick={() => handleDecision('REJECT')}
                  disabled={processingDecision}
                  className="px-4 py-2.5 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-bold text-xs"
                >
                  Reject Application
                </button>

                <button
                  type="button"
                  onClick={() => handleDecision('APPROVE')}
                  disabled={processingDecision}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 flex items-center gap-1.5"
                >
                  {processingDecision ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Executing Disbursement...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Approve & Disburse Loan</span>
                    </>
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
