import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import AuthModal from './components/AuthModal';
import CustomerDashboard from './components/CustomerDashboard';
import EmployeeDashboard from './components/EmployeeDashboard';
import ManagerDashboard from './components/ManagerDashboard';
import NotificationDrawer from './components/NotificationDrawer';
import AuditLogModal from './components/AuditLogModal';
import EMICalculatorModal from './components/EMICalculatorModal';
import RAGAssistantModal from './components/RAGAssistantModal';
import { getUser, clearAuth, api, NotificationWebSocket } from './api';
import { Bell, CheckCircle2, AlertTriangle, Shield, X } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState(getUser());
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Real-time notifications state
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  
  // Live Toast popup for new incoming WebSocket events
  const [liveToast, setLiveToast] = useState(null);

  // Modals
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isRAGModalOpen, setIsRAGModalOpen] = useState(false);

  // Initialize tabs based on user role
  useEffect(() => {
    if (currentUser) {
      if (currentUser.role === 'CUSTOMER') {
        setActiveTab('dashboard');
      } else if (currentUser.role === 'EMPLOYEE') {
        setActiveTab('verification');
      } else if (currentUser.role === 'MANAGER') {
        setActiveTab('manager-dashboard');
      }
      loadNotifications();
    }
  }, [currentUser]);

  // Setup WebSocket connection
  useEffect(() => {
    if (!currentUser) return;

    const ws = new NotificationWebSocket(
      (newNotification) => {
        // Trigger live toast on UI immediately without page refresh
        setLiveToast(newNotification);
        setNotifications((prev) => [newNotification, ...prev]);
        setUnreadCount((prev) => prev + 1);

        // Auto dismiss live toast after 6 seconds
        setTimeout(() => {
          setLiveToast((current) => (current === newNotification ? null : current));
        }, 6000);
      },
      (status) => {
        setWsConnected(status);
      }
    );

    ws.connect();

    // Listen for auth expiration
    const handleAuthExpired = () => {
      setCurrentUser(null);
    };
    window.addEventListener('loanpulse_auth_expired', handleAuthExpired);

    return () => {
      ws.close();
      window.removeEventListener('loanpulse_auth_expired', handleAuthExpired);
    };
  }, [currentUser]);

  const loadNotifications = async () => {
    try {
      const list = await api.getNotifications();
      setNotifications(list);
      setUnreadCount(list.filter((n) => !n.is_read).length);
    } catch (err) {
      console.warn('Could not load notifications history:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    clearAuth();
    setCurrentUser(null);
  };

  const handleFastSwitchRole = async (targetRole) => {
    try {
      let email = 'customer@loanpulse.com';
      if (targetRole === 'EMPLOYEE') email = 'employee@loanpulse.com';
      if (targetRole === 'MANAGER') email = 'manager@loanpulse.com';
      const data = await api.login(email, 'password123');
      setCurrentUser(data.user);
    } catch (err) {
      console.error('Failed to quick-switch role:', err);
    }
  };

  // If user is not authenticated, render Login/Landing view
  if (!currentUser) {
    return (
      <AuthModal
        onLoginSuccess={(user) => {
          setCurrentUser(user);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-blue-600 selection:text-white">
      
      {/* Top Floating Live WebSocket Toast */}
      {liveToast && (
        <div className="fixed top-20 right-4 z-50 max-w-sm w-full bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-white/20 flex items-start gap-3 animate-fade-in">
          <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5">
            <Bell className="w-4 h-4 animate-bounce" />
          </div>
          <div className="flex-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-blue-300 uppercase tracking-wider text-[10px]">
                ⚡ Real-Time Push Notification
              </span>
              <button
                onClick={() => setLiveToast(null)}
                className="text-slate-400 hover:text-white p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="font-bold text-white text-xs mt-1">{liveToast.title}</p>
            <p className="text-slate-300 text-[11px] mt-0.5 leading-relaxed">{liveToast.message}</p>
          </div>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        user={currentUser}
        onLogout={handleLogout}
        unreadCount={unreadCount}
        onToggleNotifications={() => setIsNotificationDrawerOpen(!isNotificationDrawerOpen)}
        wsConnected={wsConnected}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuditLogs={() => setIsAuditModalOpen(true)}
        onOpenCalculator={() => setIsCalculatorOpen(true)}
        onOpenRAG={() => setIsRAGModalOpen(true)}
        onSwitchRole={handleFastSwitchRole}
      />

      {/* Portal Views by Role */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentUser.role === 'CUSTOMER' && (
          <CustomerDashboard
            user={currentUser}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onRefreshBadge={loadNotifications}
            onOpenRAG={() => setIsRAGModalOpen(true)}
          />
        )}

        {currentUser.role === 'EMPLOYEE' && (
          <EmployeeDashboard
            user={currentUser}
            onRefreshBadge={loadNotifications}
          />
        )}

        {currentUser.role === 'MANAGER' && (
          <ManagerDashboard
            user={currentUser}
            onRefreshBadge={loadNotifications}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <NotificationDrawer
        isOpen={isNotificationDrawerOpen}
        onClose={() => setIsNotificationDrawerOpen(false)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllRead}
      />

      <AuditLogModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
      />

      <EMICalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
      />

      <RAGAssistantModal
        isOpen={isRAGModalOpen}
        onClose={() => setIsRAGModalOpen(false)}
        userContext={currentUser}
      />

      {/* Enterprise Architecture Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-600" />
            <span className="font-bold text-slate-800">LoanPulse Enterprise Platform</span>
            <span>• Three-Layer Relational Core Banking System</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
            <span>Presentation: React 19</span>
            <span>Logic: Django REST + Channels</span>
            <span>Data: Oracle DB Relational Schema</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
