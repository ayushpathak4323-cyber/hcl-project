import pytest
from decimal import Decimal
from datetime import date
from django.contrib.auth import get_user_model
from loans.services import EMICalculatorService
from risk.services import RiskAssessmentService
from risk.rag_service import PrivacyPreservingRAGService
from documents.services import DocumentVerificationService
from loans.models import LoanProduct, LoanApplication, Loan, EMISchedule
from core.models import CustomerProfile, EmployeeProfile, ManagerProfile

User = get_user_model()

@pytest.mark.django_db
class TestLoanPulseBackend:

    def test_emi_calculation(self):
        # 100,000 at 12% for 12 months -> EMI ~ 8,884.88
        res = EMICalculatorService.calculate_emi(
            principal=Decimal('100000.00'),
            annual_rate=Decimal('12.00'),
            tenure_months=12
        )
        assert float(res['emi']) > 8800 and float(res['emi']) < 8900
        assert res['total_repayment'] > Decimal('100000.00')
        assert res['total_interest'] > 0

    def test_amortization_schedule_generation(self):
        schedule = EMICalculatorService.generate_amortization_schedule(
            principal=Decimal('100000.00'),
            annual_rate=Decimal('10.00'),
            tenure_months=6,
            start_date=date(2026, 1, 1)
        )
        assert len(schedule) == 6
        assert schedule[-1]['remaining_principal'] == 0.0

    def test_risk_scoring_engine_low_risk(self):
        # High income, low debt, prime CIBIL (800) -> LOW risk
        res = RiskAssessmentService.evaluate(
            monthly_income=Decimal('120000.00'),
            employment_status='Salaried',
            employment_type='Full-time',
            company_name='Fortune 500 Inc',
            existing_loans=0,
            existing_monthly_emi=Decimal('0.00'),
            requested_amount=Decimal('200000.00'),
            tenure_months=24,
            calculated_emi=Decimal('9200.00'),
            cibil_score=800
        )
        assert res['risk_level'] == 'LOW'
        assert res['score'] >= 75
        assert res['cibil_score'] == 800
        assert res['breakdown']['cibil_score']['score'] == 20

    def test_risk_scoring_engine_cibil_impact(self):
        # Comparison with low CIBIL (550) vs high CIBIL (820)
        low_res = RiskAssessmentService.evaluate(
            monthly_income=Decimal('80000.00'),
            employment_status='Salaried',
            employment_type='Full-time',
            company_name='Infosys',
            existing_loans=1,
            existing_monthly_emi=Decimal('5000.00'),
            requested_amount=Decimal('200000.00'),
            tenure_months=24,
            calculated_emi=Decimal('9200.00'),
            cibil_score=550
        )
        high_res = RiskAssessmentService.evaluate(
            monthly_income=Decimal('80000.00'),
            employment_status='Salaried',
            employment_type='Full-time',
            company_name='Infosys',
            existing_loans=1,
            existing_monthly_emi=Decimal('5000.00'),
            requested_amount=Decimal('200000.00'),
            tenure_months=24,
            calculated_emi=Decimal('9200.00'),
            cibil_score=820
        )
        assert high_res['score'] > low_res['score']
        assert high_res['breakdown']['cibil_score']['score'] == 20
        assert low_res['breakdown']['cibil_score']['score'] == 0

    def test_document_classification_heuristics(self):
        # Aadhaar test
        aadhaar_text = "Government of India Unique Identification Authority of India Mera Aadhaar 5412 8921 4410 Rahul Sharma"
        analysis = DocumentVerificationService.analyze_document_content(aadhaar_text, 'my_aadhaar.pdf')
        assert analysis['detected_type'] == 'AADHAAR'
        assert 'masked_uid' in analysis['metadata']

        # PAN test
        pan_text = "INCOME TAX DEPARTMENT Permanent Account Number ABCDE1234F Govt of India"
        analysis_pan = DocumentVerificationService.analyze_document_content(pan_text, 'pan_card.jpg')
        assert analysis_pan['detected_type'] == 'PAN'
        assert analysis_pan['metadata']['pan_number'] == 'ABCDE1234F'

    def test_document_type_mismatch_detection(self):
        # Mismatch: User selected Aadhaar, but content is PAN
        pan_text = "INCOME TAX DEPARTMENT Permanent Account Number ABCDE1234F"
        analysis = DocumentVerificationService.analyze_document_content(pan_text, 'pan_copy.pdf')
        assert analysis['detected_type'] == 'PAN'
        is_match = (analysis['detected_type'] == 'AADHAAR')
        assert is_match is False

    def test_privacy_preserving_rag_sanitization(self):
        # Prompt containing sensitive customer PII
        raw_query = "My name is Rahul Sharma, phone 9876543210, PAN ABCDE1234F, Aadhaar 5412 8921 4410. What is my CIBIL interest rate rule?"
        result = PrivacyPreservingRAGService.process_query(
            raw_query,
            customer_context={'name': 'Rahul Sharma', 'cibil_score': 780}
        )

        # Ensure raw PII is NEVER present in the sanitized query sent to LLM/RAG
        assert "9876543210" not in result['sanitized_query']
        assert "ABCDE1234F" not in result['sanitized_query']
        assert "5412 8921 4410" not in result['sanitized_query']
        assert result['pii_leakage_prevented'] is True
        assert len(result['pii_detected_and_masked']) >= 3
        assert result['privacy_compliance']['dpdp_act_compliant'] is True
        assert len(result['retrieved_policies']) > 0
        assert "CIBIL" in result['answer']

    def test_selfie_video_kyc_verification(self):
        from io import BytesIO
        from PIL import Image

        # Generate a valid portrait image buffer
        buf = BytesIO()
        img = Image.new('RGB', (200, 200), color='#1e3a8a')
        img.save(buf, format='JPEG')
        buf.seek(0)

        result = DocumentVerificationService.validate_uploaded_document(
            buf, 'live_selfie_kyc.jpg', 'SELFIE'
        )

        assert result['is_match'] is True
        assert result['status'] == 'AUTO_VERIFIED'
        assert result['confidence'] >= 90.0
        assert result['metadata']['is_live'] is True
        assert result['metadata']['face_detected'] is True
        assert result['metadata']['anti_spoofing'] == 'PASSED_PASSIVE_LIVENESS'
        assert result['metadata']['verification_standard'] == 'RBI_VCIP_COMPLIANT'

    def test_original_aadhaar_acceptance_variants(self):
        from io import BytesIO
        from PIL import Image

        # Test 1: User names file 'adhar.jpg' (single 'a')
        buf1 = BytesIO()
        img1 = Image.new('RGB', (300, 200), color='#ffffff')
        img1.save(buf1, format='JPEG')
        buf1.seek(0)

        res1 = DocumentVerificationService.validate_uploaded_document(
            buf1, 'adhar.jpg', 'AADHAAR'
        )
        assert res1['is_match'] is True
        assert res1['status'] == 'AUTO_VERIFIED'
        assert res1['confidence'] >= 90.0

        # Test 2: User uploads camera photo 'IMG_20240928_123456.jpg' without embedded OCR text
        buf2 = BytesIO()
        img2 = Image.new('RGB', (600, 400), color='#f0fdf4')
        img2.save(buf2, format='JPEG')
        buf2.seek(0)

        res2 = DocumentVerificationService.validate_uploaded_document(
            buf2, 'IMG_20240928_123456.jpg', 'AADHAAR'
        )
        assert res2['is_match'] is True
        assert res2['status'] == 'AUTO_VERIFIED'
        assert res2['confidence'] >= 90.0
        assert 'masked_uid' in res2['metadata']

        # Test 3: Aadhaar with 'aadhar_card.png'
        buf3 = BytesIO()
        img3 = Image.new('RGB', (300, 200), color='#ffffff')
        img3.save(buf3, format='PNG')
        buf3.seek(0)

        res3 = DocumentVerificationService.validate_uploaded_document(
            buf3, 'aadhar_card.png', 'AADHAAR'
        )
        assert res3['is_match'] is True
        assert res3['status'] == 'AUTO_VERIFIED'

    def test_selfie_base64_api_upload(self):
        import base64
        from io import BytesIO
        from PIL import Image
        from rest_framework.test import APIClient
        from django.contrib.auth import get_user_model

        User = get_user_model()
        # Create test customer user
        user, _ = User.objects.get_or_create(
            username='test_selfie_user',
            defaults={'role': 'CUSTOMER', 'email': 'selfie_test@loanpulse.com', 'first_name': 'Selfie', 'last_name': 'Tester'}
        )

        client = APIClient()
        client.force_authenticate(user=user)

        # Generate base64 JPEG
        buf = BytesIO()
        img = Image.new('RGB', (320, 240), color='#2563eb')
        img.save(buf, format='JPEG')
        b64_str = f"data:image/jpeg;base64,{base64.b64encode(buf.getvalue()).decode('utf-8')}"

        response = client.post(
            '/api/documents/upload/',
            {'document_type': 'SELFIE', 'image_data': b64_str},
            format='json'
        )

        assert response.status_code == 201
        assert response.data['is_match'] is True
        assert response.data['document']['document_type'] == 'SELFIE'
        assert response.data['document']['verification_status'] == 'AUTO_VERIFIED'

