from decimal import Decimal

class RiskAssessmentService:
    """
    Transparent, explainable, and configurable credit risk evaluation engine.
    Produces score (0-100), risk level (LOW/MEDIUM/HIGH), factor breakdown,
    and a structured narrative explanation.
    Now incorporates CIBIL Credit Bureau Scoring (300 - 900).
    """

    # Scoring Weights (Total = 100)
    WEIGHT_CIBIL = 20
    WEIGHT_DTI = 20
    WEIGHT_INCOME_STABILITY = 20
    WEIGHT_DEBT_BURDEN = 15
    WEIGHT_LTI = 15
    WEIGHT_TENURE_REPAYMENT = 10

    @classmethod
    def evaluate(cls, 
                 monthly_income: Decimal,
                 employment_status: str,
                 employment_type: str,
                 company_name: str,
                 existing_loans: int,
                 existing_monthly_emi: Decimal,
                 requested_amount: Decimal,
                 tenure_months: int,
                 calculated_emi: Decimal,
                 cibil_score: int = 750,
                 past_defaults: int = 0) -> dict:
        
        income = float(monthly_income) if monthly_income > 0 else 1.0
        existing_emi = float(existing_monthly_emi)
        req_amount = float(requested_amount)
        new_emi = float(calculated_emi)
        cibil = int(cibil_score) if cibil_score else 750

        # 1. CIBIL Bureau Credit Score (300 to 900)
        cibil_score_rating = "Excellent"
        if cibil >= 750:
            cibil_points = cls.WEIGHT_CIBIL
            cibil_score_rating = "Excellent (750+)"
        elif cibil >= 700:
            cibil_points = int(cls.WEIGHT_CIBIL * 0.80)
            cibil_score_rating = "Good (700-749)"
        elif cibil >= 650:
            cibil_points = int(cls.WEIGHT_CIBIL * 0.50)
            cibil_score_rating = "Fair (650-699)"
        elif cibil >= 600:
            cibil_points = int(cls.WEIGHT_CIBIL * 0.25)
            cibil_score_rating = "Below Average (600-649)"
        else:
            cibil_points = 0
            cibil_score_rating = "Poor / High Risk (<600)"

        # 2. Debt-To-Income (DTI) Ratio including the proposed new EMI
        total_monthly_obligations = existing_emi + new_emi
        dti_ratio = (total_monthly_obligations / income) * 100.0  # percentage

        if dti_ratio <= 30.0:
            dti_score = cls.WEIGHT_DTI
        elif dti_ratio <= 40.0:
            dti_score = int(cls.WEIGHT_DTI * 0.80)
        elif dti_ratio <= 50.0:
            dti_score = int(cls.WEIGHT_DTI * 0.60)
        elif dti_ratio <= 65.0:
            dti_score = int(cls.WEIGHT_DTI * 0.35)
        else:
            dti_score = 0

        # 3. Income Stability & Employment Type
        emp_status = employment_status.lower()
        emp_type = employment_type.lower()
        income_score = 0
        if 'salaried' in emp_status or 'full-time' in emp_type:
            income_score = cls.WEIGHT_INCOME_STABILITY
        elif 'self' in emp_status or 'business' in emp_status:
            income_score = int(cls.WEIGHT_INCOME_STABILITY * 0.80)
        elif 'contract' in emp_type or 'part-time' in emp_type:
            income_score = int(cls.WEIGHT_INCOME_STABILITY * 0.50)
        else:
            income_score = int(cls.WEIGHT_INCOME_STABILITY * 0.40)

        # Higher monthly income adjustment
        if income >= 100000:
            income_score = min(cls.WEIGHT_INCOME_STABILITY, income_score + 2)
        elif income < 25000:
            income_score = max(0, income_score - 4)

        # 4. Existing Debt Burden (Number of Active Loans)
        if existing_loans == 0:
            debt_score = cls.WEIGHT_DEBT_BURDEN
        elif existing_loans == 1:
            debt_score = int(cls.WEIGHT_DEBT_BURDEN * 0.85)
        elif existing_loans == 2:
            debt_score = int(cls.WEIGHT_DEBT_BURDEN * 0.65)
        elif existing_loans <= 4:
            debt_score = int(cls.WEIGHT_DEBT_BURDEN * 0.40)
        else:
            debt_score = 0

        # 5. Loan-to-Income (LTI) Multiplier
        lti_multiplier = req_amount / income
        if lti_multiplier <= 5.0:
            lti_score = cls.WEIGHT_LTI
        elif lti_multiplier <= 10.0:
            lti_score = int(cls.WEIGHT_LTI * 0.80)
        elif lti_multiplier <= 15.0:
            lti_score = int(cls.WEIGHT_LTI * 0.50)
        elif lti_multiplier <= 20.0:
            lti_score = int(cls.WEIGHT_LTI * 0.25)
        else:
            lti_score = 0

        # 6. Tenure and Repayment Track Record
        repayment_score = cls.WEIGHT_TENURE_REPAYMENT
        if past_defaults > 0:
            repayment_score = max(0, repayment_score - (past_defaults * 5))
        if tenure_months > 60:
            repayment_score = max(0, repayment_score - 2)

        # Total Aggregate Score (0 to 100)
        total_score = min(100, max(0, cibil_points + dti_score + income_score + debt_score + lti_score + repayment_score))

        # Risk Classification Level
        if total_score >= 75:
            risk_level = 'LOW'
        elif total_score >= 50:
            risk_level = 'MEDIUM'
        else:
            risk_level = 'HIGH'

        # Narrative Generation
        strengths = []
        concerns = []

        if cibil >= 750:
            strengths.append(f"Strong CIBIL credit score of {cibil} reflects exemplary credit discipline and minimal default likelihood.")
        elif cibil >= 680:
            strengths.append(f"Satisfactory CIBIL score of {cibil} meets standard prime lending benchmarks.")
        else:
            concerns.append(f"Sub-prime CIBIL score of {cibil} indicates elevated historical delinquency risk.")

        if dti_ratio <= 35:
            strengths.append(f"Favorable Debt-To-Income ratio of {dti_ratio:.1f}% indicates manageable repayment capacity.")
        else:
            concerns.append(f"Elevated Debt-To-Income ratio of {dti_ratio:.1f}% warrants scrutiny on disposable income.")

        if 'salaried' in emp_status:
            strengths.append("Applicant has stable salaried employment profile.")
        
        if existing_loans <= 1:
            strengths.append("Minimal existing debt liabilities.")
        else:
            concerns.append(f"Applicant has {existing_loans} concurrent active loans.")

        if lti_multiplier <= 8:
            strengths.append(f"Requested loan amount is within safe income bounds ({lti_multiplier:.1f}x monthly income).")
        else:
            concerns.append(f"High loan exposure ({lti_multiplier:.1f}x monthly income).")

        if risk_level == 'LOW':
            summary = (
                f"Applicant demonstrates strong financial capacity with a score of {total_score}/100. "
                f"Influenced by prime CIBIL score ({cibil}), stable income, low obligations, and a sound DTI of {dti_ratio:.1f}%. "
                f"Recommended for standard processing."
            )
        elif risk_level == 'MEDIUM':
            summary = (
                f"Applicant exhibits moderate credit risk with a score of {total_score}/100. "
                f"CIBIL rating: {cibil_score_rating}. Debt-To-Income ratio: {dti_ratio:.1f}%. "
                f"Additional income verification or co-borrower endorsement recommended."
            )
        else:
            summary = (
                f"High credit risk detected with score {total_score}/100. "
                f"Primary risk drivers: CIBIL score of {cibil} and DTI ratio of {dti_ratio:.1f}%. "
                f"Detailed scrutiny or loan amount reduction required."
            )

        ai_explanation = (
            f"### Comprehensive Underwriting Assessment\n\n"
            f"**Overall Assessment**: {risk_level} Risk (Score: {total_score}/100 | CIBIL: {cibil})\n\n"
            f"**Key Supporting Strengths**:\n" + ("\n".join([f"- {s}" for s in strengths]) if strengths else "- Adequate income profile.") + "\n\n"
            f"**Underwriting Concerns**:\n" + ("\n".join([f"- {c}" for c in concerns]) if concerns else "- None noted.") + "\n\n"
            f"**Regulatory Note**: This algorithmic assessment is advisory. The final approval decision is reserved for the designated Loan Officer and Manager."
        )

        return {
            'score': total_score,
            'risk_level': risk_level,
            'cibil_score': cibil,
            'cibil_rating': cibil_score_rating,
            'dti_ratio': round(dti_ratio, 2),
            'lti_multiplier': round(lti_multiplier, 2),
            'breakdown': {
                'cibil_score': {'score': cibil_points, 'max': cls.WEIGHT_CIBIL, 'metric': f"{cibil} ({cibil_score_rating})"},
                'dti_score': {'score': dti_score, 'max': cls.WEIGHT_DTI, 'metric': f"{dti_ratio:.1f}%"},
                'income_stability_score': {'score': income_score, 'max': cls.WEIGHT_INCOME_STABILITY, 'metric': employment_status},
                'debt_burden_score': {'score': debt_score, 'max': cls.WEIGHT_DEBT_BURDEN, 'metric': f"{existing_loans} loans"},
                'lti_score': {'score': lti_score, 'max': cls.WEIGHT_LTI, 'metric': f"{lti_multiplier:.1f}x"},
                'repayment_score': {'score': repayment_score, 'max': cls.WEIGHT_TENURE_REPAYMENT, 'metric': f"{tenure_months}m tenure"}
            },
            'recommendation_summary': summary,
            'ai_generated_explanation': ai_explanation
        }
