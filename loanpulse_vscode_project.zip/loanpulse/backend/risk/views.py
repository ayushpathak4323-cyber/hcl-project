from decimal import Decimal
from rest_framework import views, permissions, status
from rest_framework.response import Response
from .models import RiskAssessment
from .services import RiskAssessmentService
from .rag_service import PrivacyPreservingRAGService
from loans.services import EMICalculatorService
from loans.serializers import RiskAssessmentSerializer

class RiskAssessmentDetailView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, application_id):
        risk = RiskAssessment.objects.filter(application_id=application_id).first()
        if not risk:
            return Response({'error': 'Risk assessment not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response(RiskAssessmentSerializer(risk).data)


class RiskSimulationView(views.APIView):
    """
    Interactive API for testing and evaluating risk scenarios on the fly with CIBIL score.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        try:
            monthly_income = Decimal(str(request.data.get('monthly_income', 75000)))
            employment_status = request.data.get('employment_status', 'Salaried')
            employment_type = request.data.get('employment_type', 'Full-time')
            company_name = request.data.get('company_name', 'Tech Corp')
            existing_loans = int(request.data.get('existing_loans', 0))
            existing_monthly_emi = Decimal(str(request.data.get('existing_monthly_emi', 0)))
            cibil_score = int(request.data.get('cibil_score', 750))
            requested_amount = Decimal(str(request.data.get('requested_amount', 300000)))
            tenure_months = int(request.data.get('tenure_months', 24))
            interest_rate = Decimal(str(request.data.get('interest_rate', 11.5)))

            emi_calc = EMICalculatorService.calculate_emi(requested_amount, interest_rate, tenure_months)

            evaluation = RiskAssessmentService.evaluate(
                monthly_income=monthly_income,
                employment_status=employment_status,
                employment_type=employment_type,
                company_name=company_name,
                existing_loans=existing_loans,
                existing_monthly_emi=existing_monthly_emi,
                requested_amount=requested_amount,
                tenure_months=tenure_months,
                calculated_emi=emi_calc['emi'],
                cibil_score=cibil_score
            )

            return Response({
                'simulation_inputs': {
                    'monthly_income': monthly_income,
                    'requested_amount': requested_amount,
                    'tenure_months': tenure_months,
                    'cibil_score': cibil_score,
                    'calculated_emi': emi_calc['emi']
                },
                'risk_evaluation': evaluation
            })
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class PrivacyPreservingRAGView(views.APIView):
    """
    Privacy-Preserving Retrieval-Augmented Generation (RAG) API.
    Interprets lending policies, answers customer underwriting questions,
    and guarantees zero PII privacy violation via automatic sanitization.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        query = request.data.get('query', '').strip()
        if not query:
            return Response({'error': 'Query text is required'}, status=status.HTTP_400_BAD_REQUEST)

        # Build user context
        user = request.user
        context = {
            'name': user.get_full_name() or user.username,
            'email': user.email,
            'phone': user.phone,
        }

        if hasattr(user, 'customer_profile'):
            profile = user.customer_profile
            context['cibil_score'] = profile.cibil_score
            context['monthly_income'] = str(profile.monthly_income)
            context['pan'] = profile.pan_number

        result = PrivacyPreservingRAGService.process_query(query, context)
        return Response(result, status=status.HTTP_200_OK)
