from django.db import models

class RiskAssessment(models.Model):
    class RiskLevel(models.TextChoices):
        LOW = 'LOW', 'Low Risk'
        MEDIUM = 'MEDIUM', 'Medium Risk'
        HIGH = 'HIGH', 'High Risk'

    application = models.OneToOneField(
        'loans.LoanApplication',
        on_delete=models.CASCADE,
        related_name='risk_assessment'
    )
    score = models.IntegerField(default=0)  # 0 to 100
    risk_level = models.CharField(max_length=20, choices=RiskLevel.choices, default=RiskLevel.MEDIUM)
    
    # Financial metrics
    debt_to_income_ratio = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    loan_to_income_ratio = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    
    # Component breakdown scores (each out of their respective weight)
    income_stability_score = models.IntegerField(default=0)
    existing_debt_score = models.IntegerField(default=0)
    dti_score = models.IntegerField(default=0)
    repayment_history_score = models.IntegerField(default=0)
    loan_amount_suitability_score = models.IntegerField(default=0)
    cibil_score = models.IntegerField(default=750)
    cibil_rating_score = models.IntegerField(default=20)
    
    # Transparent scoring metadata
    factors_breakdown = models.JSONField(default=dict, blank=True)
    recommendation_summary = models.TextField()
    ai_generated_explanation = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_RISK_ASSESSMENTS'
        ordering = ['-created_at']

    def __str__(self):
        return f"Risk Assessment for {self.application.application_number}: Score {self.score} ({self.risk_level})"
