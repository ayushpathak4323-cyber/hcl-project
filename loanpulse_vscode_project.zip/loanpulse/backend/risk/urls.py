from django.urls import path
from .views import RiskAssessmentDetailView, RiskSimulationView, PrivacyPreservingRAGView

urlpatterns = [
    path('application/<int:application_id>/', RiskAssessmentDetailView.as_view(), name='risk_detail'),
    path('simulate/', RiskSimulationView.as_view(), name='risk_simulate'),
    path('rag-query/', PrivacyPreservingRAGView.as_view(), name='rag_query'),
]
