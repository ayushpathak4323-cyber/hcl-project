import os
import django
from decimal import Decimal
from datetime import date, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'loanpulse_project.settings')
django.setup()

from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from core.models import CustomerProfile, EmployeeProfile, ManagerProfile, AuditLog, Notification
from loans.models import LoanProduct, LoanApplication, VerificationReport, Loan, EMISchedule, Payment
from documents.models import Document
from risk.models import RiskAssessment
from loans.services import EMICalculatorService
from risk.services import RiskAssessmentService

User = get_user_model()

def seed():
    print("[*] Seeding LoanPulse Database...")

    # 1. Loan Products
    products_data = [
        {
            'code': 'PERSONAL',
            'name': 'Personal Flexi Loan',
            'interest_rate_min': Decimal('10.50'),
            'interest_rate_max': Decimal('14.50'),
            'min_amount': Decimal('50000.00'),
            'max_amount': Decimal('1500000.00'),
            'min_tenure_months': 6,
            'max_tenure_months': 60,
            'description': 'Unsecured multi-purpose loan with instant approval and flexible tenure.'
        },
        {
            'code': 'HOME',
            'name': 'Prime Home Mortgage',
            'interest_rate_min': Decimal('8.40'),
            'interest_rate_max': Decimal('10.20'),
            'min_amount': Decimal('500000.00'),
            'max_amount': Decimal('20000000.00'),
            'min_tenure_months': 24,
            'max_tenure_months': 360,
            'description': 'Affordable home financing with minimal processing fees and tax benefits.'
        },
        {
            'code': 'AUTO',
            'name': 'DriveEasy Auto Loan',
            'interest_rate_min': Decimal('9.20'),
            'interest_rate_max': Decimal('12.00'),
            'min_amount': Decimal('100000.00'),
            'max_amount': Decimal('3000000.00'),
            'min_tenure_months': 12,
            'max_tenure_months': 84,
            'description': 'Drive home your dream vehicle with 100% on-road funding options.'
        },
        {
            'code': 'BUSINESS',
            'name': 'Enterprise Growth Loan',
            'interest_rate_min': Decimal('12.00'),
            'interest_rate_max': Decimal('16.50'),
            'min_amount': Decimal('200000.00'),
            'max_amount': Decimal('10000000.00'),
            'min_tenure_months': 12,
            'max_tenure_months': 60,
            'description': 'Working capital and machinery loans for expanding SME business operations.'
        }
    ]

    for pdata in products_data:
        prod, _ = LoanProduct.objects.get_or_create(code=pdata['code'], defaults=pdata)
        print(f"   Loan Product: {prod.name}")

    # 2. Seed Users
    # Customer
    customer_user, created = User.objects.get_or_create(
        username='customer@loanpulse.com',
        defaults={
            'email': 'customer@loanpulse.com',
            'first_name': 'Rahul',
            'last_name': 'Sharma',
            'role': User.Role.CUSTOMER,
            'phone': '9876543210'
        }
    )
    customer_user.set_password('password123')
    customer_user.save()

    CustomerProfile.objects.update_or_create(
        user=customer_user,
        defaults={
            'dob': date(1994, 6, 15),
            'pan_number': 'ABCDE1234F',
            'aadhaar_last_four': '8921',
            'address': 'Flat 402, Skyline Towers, Sector 62',
            'city': 'Noida',
            'state': 'Uttar Pradesh',
            'pincode': '201309',
            'employment_status': 'Salaried',
            'employment_type': 'Full-time',
            'company_name': 'Infosys Technologies Ltd',
            'monthly_income': Decimal('85000.00'),
            'existing_loans': 1,
            'existing_monthly_emi': Decimal('7500.00'),
            'bank_account_number': '918020045812901',
            'bank_ifsc': 'HDFC0001024'
        }
    )
    print(f"   Customer Account: customer@loanpulse.com / password123")

    # Employee
    employee_user, created = User.objects.get_or_create(
        username='employee@loanpulse.com',
        defaults={
            'email': 'employee@loanpulse.com',
            'first_name': 'Priya',
            'last_name': 'Desai',
            'role': User.Role.EMPLOYEE,
            'employee_id': 'EMP104',
            'phone': '9812345678'
        }
    )
    employee_user.set_password('password123')
    employee_user.save()

    EmployeeProfile.objects.update_or_create(
        user=employee_user,
        defaults={
            'employee_code': 'EMP104',
            'department': 'Credit Risk & Document Verification',
            'designation': 'Senior Underwriting Officer'
        }
    )
    print(f"   Employee Account: employee@loanpulse.com / password123 [EMP104]")

    # Manager
    manager_user, created = User.objects.get_or_create(
        username='manager@loanpulse.com',
        defaults={
            'email': 'manager@loanpulse.com',
            'first_name': 'Vikramaditya',
            'last_name': 'Singh',
            'role': User.Role.MANAGER,
            'employee_id': 'MGR001',
            'phone': '9899001122'
        }
    )
    manager_user.set_password('password123')
    manager_user.save()

    ManagerProfile.objects.update_or_create(
        user=manager_user,
        defaults={
            'manager_code': 'MGR001',
            'approval_limit': Decimal('10000000.00')
        }
    )
    print(f"   Manager Account: manager@loanpulse.com / password123 [MGR001]")

    # 3. Seed an Active Disbursed Loan for Rahul Sharma
    personal_prod = LoanProduct.objects.get(code='PERSONAL')
    existing_app, created = LoanApplication.objects.get_or_create(
        application_number='LP10088',
        defaults={
            'customer': customer_user,
            'loan_product': personal_prod,
            'loan_purpose': 'Home Renovation & Appliances',
            'requested_amount': Decimal('200000.00'),
            'tenure_months': 12,
            'interest_rate': Decimal('10.50'),
            'calculated_emi': Decimal('17631.00'),
            'total_interest': Decimal('11572.00'),
            'total_repayment': Decimal('211572.00'),
            'status': LoanApplication.Status.APPROVED,
            'assigned_employee': employee_user,
            'assigned_manager': manager_user,
            'employee_remarks': 'All KYC documents and income statements verified against EPFO records.',
            'manager_remarks': 'Approved within delegated underwriting discretion.'
        }
    )

    disbursed_loan, created = Loan.objects.get_or_create(
        loan_account_number='LN-2026-10088',
        defaults={
            'application': existing_app,
            'customer': customer_user,
            'approved_amount': Decimal('200000.00'),
            'interest_rate': Decimal('10.50'),
            'tenure_months': 12,
            'monthly_emi': Decimal('17631.00'),
            'total_interest': Decimal('11572.00'),
            'total_payable': Decimal('211572.00'),
            'disbursed_amount': Decimal('200000.00'),
            'status': Loan.LoanStatus.ACTIVE
        }
    )

    if EMISchedule.objects.filter(loan=disbursed_loan).count() == 0:
        schedules = EMICalculatorService.generate_amortization_schedule(
            principal=Decimal('200000.00'),
            annual_rate=Decimal('10.50'),
            tenure_months=12,
            start_date=date.today() - timedelta(days=90)
        )
        for idx, s in enumerate(schedules):
            # Mark first 2 installments as PAID
            if idx < 2:
                status_val = EMISchedule.EMIStatus.PAID
                paid_dt = s['due_date']
                txn = f"TXN-202607{idx+1}0-AUTO"
            else:
                status_val = EMISchedule.EMIStatus.PENDING
                paid_dt = None
                txn = ""

            emi_obj = EMISchedule.objects.create(
                loan=disbursed_loan,
                installment_number=s['installment_number'],
                due_date=s['due_date'],
                emi_amount=s['emi_amount'],
                principal_component=s['principal_component'],
                interest_component=s['interest_component'],
                remaining_principal=s['remaining_principal'],
                status=status_val,
                paid_date=paid_dt,
                transaction_reference=txn
            )

            if status_val == EMISchedule.EMIStatus.PAID:
                Payment.objects.create(
                    loan=disbursed_loan,
                    emi_schedule=emi_obj,
                    amount_paid=s['emi_amount'],
                    payment_method='AUTO_DEBIT_NACH',
                    payment_status='SUCCESS',
                    transaction_reference=txn
                )

    print(f"   Active Loan & EMI Schedule: LN-2026-10088 (2 EMIs paid, 10 pending)")

    # 4. Seed an Application pending Employee Verification (LP10294)
    app2, created = LoanApplication.objects.get_or_create(
        application_number='LP10294',
        defaults={
            'customer': customer_user,
            'loan_product': personal_prod,
            'loan_purpose': 'Medical Emergency & Higher Studies',
            'requested_amount': Decimal('350000.00'),
            'tenure_months': 24,
            'interest_rate': Decimal('11.00'),
            'calculated_emi': Decimal('16307.00'),
            'total_interest': Decimal('41368.00'),
            'total_repayment': Decimal('391368.00'),
            'status': LoanApplication.Status.SUBMITTED,
        }
    )

    if not hasattr(app2, 'risk_assessment'):
        risk_res = RiskAssessmentService.evaluate(
            monthly_income=Decimal('85000.00'),
            employment_status='Salaried',
            employment_type='Full-time',
            company_name='Infosys Technologies Ltd',
            existing_loans=1,
            existing_monthly_emi=Decimal('7500.00'),
            requested_amount=Decimal('350000.00'),
            tenure_months=24,
            calculated_emi=Decimal('16307.00')
        )

        RiskAssessment.objects.create(
            application=app2,
            score=risk_res['score'],
            risk_level=risk_res['risk_level'],
            debt_to_income_ratio=risk_res['dti_ratio'],
            loan_to_income_ratio=risk_res['lti_multiplier'],
            income_stability_score=risk_res['breakdown']['income_stability_score']['score'],
            existing_debt_score=risk_res['breakdown']['debt_burden_score']['score'],
            dti_score=risk_res['breakdown']['dti_score']['score'],
            repayment_history_score=risk_res['breakdown']['repayment_score']['score'],
            loan_amount_suitability_score=risk_res['breakdown']['lti_score']['score'],
            factors_breakdown=risk_res['breakdown'],
            recommendation_summary=risk_res['recommendation_summary'],
            ai_generated_explanation=risk_res['ai_generated_explanation']
        )

    # Seed Sample Documents for LP10294
    sample_files = [
        ('AADHAAR', 'Aadhaar_Rahul_Sharma.pdf', 'Unique Identification Authority of India Government of India Aadhaar 5412 8921 4410 Rahul Sharma DOB 15/06/1994 Male'),
        ('PAN', 'PAN_Rahul_Sharma.pdf', 'Income Tax Department Govt. of India Permanent Account Number ABCDE1234F Rahul Sharma'),
        ('SALARY_SLIP', 'Salary_Slip_August2026.pdf', 'Infosys Technologies Limited Payslip Month August 2026 Basic Pay 45000 HRA 20000 Deductions PF 5400 Net Salary 85000'),
        ('BANK_STATEMENT', 'Bank_Statement_HDFC.pdf', 'HDFC Bank Account Statement Account Number 918020045812901 IFSC HDFC0001024 Average Balance 112000 Credit Salary')
    ]

    for dtype, fname, ocr_content in sample_files:
        if not Document.objects.filter(application=app2, document_type=dtype).exists():
            doc = Document(
                application=app2,
                customer=customer_user,
                document_type=dtype,
                file_name=fname,
                file_size=1024 * 142,
                mime_type='application/pdf',
                ocr_extracted_text=ocr_content,
                detected_document_type=dtype,
                confidence_score=Decimal('96.50'),
                verification_status=Document.VerificationStatus.AUTO_VERIFIED,
                extracted_metadata={'verified_channel': 'OCR Engine v2'}
            )
            doc.file.save(fname, ContentFile(f"%PDF-1.4 Mock content for {dtype}: {ocr_content}".encode('utf-8')), save=True)

    print(f"   Pending Application: LP10294 with OCR-detected Aadhaar, PAN, Salary Slip, Bank Statement")

    # 5. Seed an Application that is EMPLOYEE_VERIFIED (LP10312) ready for Manager Review
    app3, created = LoanApplication.objects.get_or_create(
        application_number='LP10312',
        defaults={
            'customer': customer_user,
            'loan_product': personal_prod,
            'loan_purpose': 'Professional Certification & Equipment',
            'requested_amount': Decimal('150000.00'),
            'tenure_months': 12,
            'interest_rate': Decimal('10.50'),
            'calculated_emi': Decimal('13223.00'),
            'total_interest': Decimal('8676.00'),
            'total_repayment': Decimal('158676.00'),
            'status': LoanApplication.Status.EMPLOYEE_VERIFIED,
            'assigned_employee': employee_user,
            'employee_remarks': 'Physical & OCR verification completed. Applicant has steady salary and zero previous default.'
        }
    )

    if not hasattr(app3, 'risk_assessment'):
        risk_res3 = RiskAssessmentService.evaluate(
            monthly_income=Decimal('85000.00'),
            employment_status='Salaried',
            employment_type='Full-time',
            company_name='Infosys Technologies Ltd',
            existing_loans=1,
            existing_monthly_emi=Decimal('7500.00'),
            requested_amount=Decimal('150000.00'),
            tenure_months=12,
            calculated_emi=Decimal('13223.00')
        )
        RiskAssessment.objects.create(
            application=app3,
            score=risk_res3['score'],
            risk_level=risk_res3['risk_level'],
            debt_to_income_ratio=risk_res3['dti_ratio'],
            loan_to_income_ratio=risk_res3['lti_multiplier'],
            income_stability_score=risk_res3['breakdown']['income_stability_score']['score'],
            existing_debt_score=risk_res3['breakdown']['debt_burden_score']['score'],
            dti_score=risk_res3['breakdown']['dti_score']['score'],
            repayment_history_score=risk_res3['breakdown']['repayment_score']['score'],
            loan_amount_suitability_score=risk_res3['breakdown']['lti_score']['score'],
            factors_breakdown=risk_res3['breakdown'],
            recommendation_summary=risk_res3['recommendation_summary'],
            ai_generated_explanation=risk_res3['ai_generated_explanation']
        )

    if not hasattr(app3, 'verification_report'):
        VerificationReport.objects.create(
            application=app3,
            employee=employee_user,
            overall_recommendation='RECOMMENDED_APPROVAL',
            remarks='Recommended for immediate approval. Verified Aadhaar and PAN numbers match national registry format.',
            risk_score_snapshot=84,
            risk_level_snapshot='LOW',
            documents_summary={'total': 4, 'verified': 4, 'rejected': 0, 'pending': 0}
        )

    print(f"   Manager Review Queue Application: LP10312 (Employee Verified)")

    # 6. Seed Sample Notifications
    Notification.objects.get_or_create(
        recipient=customer_user,
        title="Welcome to LoanPulse",
        defaults={
            'message': 'Your account is active. You can apply for personal, home, and auto loans with instant digital verification.',
            'notification_type': Notification.NotificationType.GENERAL,
            'is_read': False
        }
    )

    Notification.objects.get_or_create(
        recipient=employee_user,
        title=" New Loan Application Received  Application #LP10294",
        defaults={
            'message': 'New application submitted by Rahul Sharma for 3,50,000. Ready for document verification.',
            'notification_type': Notification.NotificationType.APPLICATION_SUBMITTED,
            'reference_id': 'LP10294',
            'is_read': False
        }
    )

    Notification.objects.get_or_create(
        recipient=manager_user,
        title="Verification Complete  Application #LP10312",
        defaults={
            'message': 'Application LP10312 has been verified by Employee EMP104 and requires final review.',
            'notification_type': Notification.NotificationType.EMPLOYEE_VERIFIED,
            'reference_id': 'LP10312',
            'is_read': False
        }
    )

    # 7. Seed Initial Audit Logs
    AuditLog.objects.create(
        user=employee_user,
        user_role='EMPLOYEE',
        action='SUBMIT_VERIFICATION_REPORT',
        application_number='LP10312',
        previous_status='UNDER_REVIEW',
        new_status='EMPLOYEE_VERIFIED',
        remarks='Employee EMP104 verified Aadhaar, PAN, and salary slips. Recommended approval.'
    )

    AuditLog.objects.create(
        user=manager_user,
        user_role='MANAGER',
        action='APPROVE_LOAN',
        application_number='LP10088',
        previous_status='EMPLOYEE_VERIFIED',
        new_status='APPROVED',
        remarks='Manager MGR001 approved loan LP10088 and disbursed LN-2026-10088.'
    )

    print(" Database successfully seeded with realistic enterprise data!")

if __name__ == '__main__':
    seed()
