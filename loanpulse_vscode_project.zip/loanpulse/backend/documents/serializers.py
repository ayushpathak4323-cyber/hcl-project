from rest_framework import serializers
from .models import Document

class DocumentSerializer(serializers.ModelSerializer):
    verified_by_name = serializers.SerializerMethodField()
    document_type_display = serializers.CharField(source='get_document_type_display', read_only=True)
    verification_status_display = serializers.CharField(source='get_verification_status_display', read_only=True)

    class Meta:
        model = Document
        fields = [
            'id', 'application', 'customer', 'document_type', 'document_type_display',
            'file', 'file_name', 'file_size', 'mime_type',
            'ocr_extracted_text', 'detected_document_type', 'confidence_score',
            'verification_status', 'verification_status_display',
            'rejection_reason', 'uploaded_at', 'verified_by', 'verified_by_name',
            'verified_at', 'extracted_metadata'
        ]
        read_only_fields = ['customer', 'ocr_extracted_text', 'detected_document_type',
                            'confidence_score', 'verification_status', 'verified_by', 'verified_at']

    def get_verified_by_name(self, obj):
        return obj.verified_by.get_full_name() if obj.verified_by else None
