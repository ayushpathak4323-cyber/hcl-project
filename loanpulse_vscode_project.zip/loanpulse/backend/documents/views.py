from rest_framework import views, status, permissions
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django.utils import timezone
import base64
from django.core.files.base import ContentFile
from .models import Document
from .serializers import DocumentSerializer
from .services import DocumentVerificationService
from core.services import NotificationService, AuditLogService
from core.views import IsStaffOrManager

class DocumentUploadValidateView(views.APIView):
    """
    Endpoint for customer document upload with automatic OCR extraction,
    type classification, and matching verification. Supports webcam live selfies.
    """
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request, *args, **kwargs):
        uploaded_file = request.FILES.get('file')
        doc_type = request.data.get('document_type')
        application_id = request.data.get('application_id')
        base64_image = request.data.get('image_data') or request.data.get('selfie_base64')

        # Handle base64 snapshot from live video webcam
        if base64_image and not uploaded_file:
            try:
                if ';base64,' in base64_image:
                    _, imgstr = base64_image.split(';base64,')
                else:
                    imgstr = base64_image
                file_bytes = base64.b64decode(imgstr)
                uploaded_file = ContentFile(
                    file_bytes,
                    name=f"live_selfie_kyc_{request.user.id}_{int(timezone.now().timestamp())}.jpg"
                )
                if not doc_type:
                    doc_type = 'SELFIE'
            except Exception as e:
                return Response({'error': f'Failed to process selfie image: {str(e)}'}, status=status.HTTP_400_BAD_REQUEST)

        if not uploaded_file:
            return Response({'error': 'No file or selfie capture provided'}, status=status.HTTP_400_BAD_REQUEST)
        if not doc_type:
            return Response({'error': 'Document type is required'}, status=status.HTTP_400_BAD_REQUEST)

        # File size validation (limit 10MB)
        if uploaded_file.size > 10 * 1024 * 1024:
            return Response({'error': 'File size exceeds maximum permitted limit of 10MB'}, status=status.HTTP_400_BAD_REQUEST)

        # Execute OCR and Detection
        validation_result = DocumentVerificationService.validate_uploaded_document(
            uploaded_file, uploaded_file.name, doc_type
        )

        # Associate with application if provided
        app_obj = None
        if application_id:
            from loans.models import LoanApplication
            app_obj = LoanApplication.objects.filter(id=application_id, customer=request.user).first()

        # Save document record
        document = Document.objects.create(
            application=app_obj,
            customer=request.user,
            document_type=doc_type,
            file=uploaded_file,
            file_name=uploaded_file.name,
            file_size=uploaded_file.size,
            mime_type=getattr(uploaded_file, 'content_type', None) or 'image/jpeg',
            ocr_extracted_text=validation_result['extracted_text'],
            detected_document_type=validation_result['detected_type'],
            confidence_score=validation_result['confidence'],
            verification_status=validation_result['status'],
            rejection_reason="" if validation_result['is_match'] else validation_result['message'],
            extracted_metadata=validation_result['metadata']
        )

        AuditLogService.log(
            user=request.user,
            action=f"UPLOAD_DOCUMENT_{doc_type}",
            application_number=app_obj.application_number if app_obj else "DRAFT",
            previous_status=None,
            new_status=document.verification_status,
            remarks=f"OCR Detection: {validation_result['detected_type']} (Confidence: {validation_result['confidence']}%)"
        )

        serializer = DocumentSerializer(document)
        response_data = {
            'document': serializer.data,
            'is_match': validation_result['is_match'],
            'message': validation_result['message'],
            'detected_type': validation_result['detected_type'],
            'confidence': validation_result['confidence'],
        }

        # If mismatch, return HTTP 422 with explanation or 200 with is_match=False
        if not validation_result['is_match']:
            return Response(response_data, status=status.HTTP_422_UNPROCESSABLE_ENTITY)

        return Response(response_data, status=status.HTTP_201_CREATED)


class DocumentReviewView(views.APIView):
    """
    Endpoint for loan officers (employees) to manually verify or reject documents.
    """
    permission_classes = [IsStaffOrManager]

    def post(self, request, pk, *args, **kwargs):
        document = Document.objects.filter(id=pk).first()
        if not document:
            return Response({'error': 'Document not found'}, status=status.HTTP_404_NOT_FOUND)

        action = request.data.get('action') # 'VERIFY' or 'REJECT'
        remarks = request.data.get('remarks', '')

        if action == 'VERIFY':
            document.verification_status = Document.VerificationStatus.VERIFIED
            document.verified_by = request.user
            document.verified_at = timezone.now()
            document.rejection_reason = ""
            document.save()

            AuditLogService.log(
                user=request.user,
                action=f"VERIFY_DOCUMENT_{document.document_type}",
                application_number=document.application.application_number if document.application else None,
                new_status="VERIFIED",
                remarks=remarks or f"Officer manually verified {document.get_document_type_display()}"
            )
            return Response({'status': 'verified', 'document': DocumentSerializer(document).data})

        elif action == 'REJECT':
            document.verification_status = Document.VerificationStatus.REJECTED
            document.verified_by = request.user
            document.verified_at = timezone.now()
            document.rejection_reason = remarks or "Document did not meet underwriting standards."
            document.save()

            # Push real-time notification to the customer
            NotificationService.notify_user(
                recipient=document.customer,
                title="Document Verification Failed",
                message=f"Your {document.get_document_type_display()} document could not be verified. Reason: {document.rejection_reason}. Please upload a valid document.",
                notification_type=Notification.NotificationType.DOCUMENT_REJECTED,
                reference_id=document.application.application_number if document.application else ""
            )

            AuditLogService.log(
                user=request.user,
                action=f"REJECT_DOCUMENT_{document.document_type}",
                application_number=document.application.application_number if document.application else None,
                new_status="REJECTED",
                remarks=document.rejection_reason
            )
            return Response({'status': 'rejected', 'document': DocumentSerializer(document).data})

        return Response({'error': 'Invalid action. Must be VERIFY or REJECT.'}, status=status.HTTP_400_BAD_REQUEST)
