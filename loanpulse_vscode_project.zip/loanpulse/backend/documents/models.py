from django.db import models
from django.conf import settings

class Document(models.Model):
    class DocumentType(models.TextChoices):
        AADHAAR = 'AADHAAR', 'Aadhaar Card'
        PAN = 'PAN', 'PAN Card'
        SALARY_SLIP = 'SALARY_SLIP', 'Salary Slip'
        BANK_STATEMENT = 'BANK_STATEMENT', 'Bank Statement'
        ADDRESS_PROOF = 'ADDRESS_PROOF', 'Address Proof'
        SELFIE = 'SELFIE', 'Live Video-KYC Selfie'

    class VerificationStatus(models.TextChoices):
        PENDING = 'PENDING', 'Pending Detection & Review'
        AUTO_VERIFIED = 'AUTO_VERIFIED', 'Document Type Auto-Verified'
        VERIFIED = 'VERIFIED', 'Verified by Officer'
        REJECTED = 'REJECTED', 'Rejected'

    application = models.ForeignKey(
        'loans.LoanApplication',
        on_delete=models.CASCADE,
        related_name='documents',
        null=True,
        blank=True
    )
    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='customer_documents'
    )
    document_type = models.CharField(max_length=40, choices=DocumentType.choices)
    file = models.FileField(upload_to='documents/%Y/%m/')
    file_name = models.CharField(max_length=255)
    file_size = models.BigIntegerField(default=0)
    mime_type = models.CharField(max_length=100, default='application/octet-stream')
    
    # OCR & Detection Results
    ocr_extracted_text = models.TextField(blank=True)
    detected_document_type = models.CharField(max_length=50, blank=True)
    confidence_score = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    
    verification_status = models.CharField(
        max_length=40,
        choices=VerificationStatus.choices,
        default=VerificationStatus.PENDING
    )
    rejection_reason = models.TextField(blank=True)
    
    uploaded_at = models.DateTimeField(auto_now_add=True)
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='verified_documents'
    )
    verified_at = models.DateTimeField(null=True, blank=True)
    extracted_metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        db_table = 'LP_DOCUMENTS'
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.get_document_type_display()} - {self.customer.username} [{self.verification_status}]"
