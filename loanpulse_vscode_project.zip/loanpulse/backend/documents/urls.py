from django.urls import path
from .views import DocumentUploadValidateView, DocumentReviewView

urlpatterns = [
    path('upload/', DocumentUploadValidateView.as_view(), name='document_upload_validate'),
    path('<int:pk>/review/', DocumentReviewView.as_view(), name='document_review'),
]
