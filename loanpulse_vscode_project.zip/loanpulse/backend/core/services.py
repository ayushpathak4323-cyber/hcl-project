from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from .models import Notification, AuditLog

class NotificationService:
    """
    Centralized Notification Service:
    Persists notifications in database and broadcasts via WebSockets immediately.
    """

    @classmethod
    def notify_user(cls, recipient, title: str, message: str, notification_type: str, reference_id: str = ""):
        # 1. Save to Database
        notification = Notification.objects.create(
            recipient=recipient,
            title=title,
            message=message,
            notification_type=notification_type,
            reference_id=reference_id
        )

        # 2. Push via WebSocket to user's personal channel
        channel_layer = get_channel_layer()
        if channel_layer:
            async_to_sync(channel_layer.group_send)(
                f"user_{recipient.id}",
                {
                    'type': 'notify',
                    'data': {
                        'id': notification.id,
                        'title': title,
                        'message': message,
                        'notification_type': notification_type,
                        'reference_id': reference_id,
                        'created_at': notification.created_at.isoformat(),
                        'is_read': False
                    }
                }
            )

        return notification

    @classmethod
    def broadcast_to_role(cls, role: str, title: str, message: str, notification_type: str, reference_id: str = ""):
        """Broadcasts live alert to all connected staff of a given role (e.g. EMPLOYEE or MANAGER)"""
        channel_layer = get_channel_layer()
        if channel_layer:
            async_to_sync(channel_layer.group_send)(
                f"role_{role}",
                {
                    'type': 'notify',
                    'data': {
                        'title': title,
                        'message': message,
                        'notification_type': notification_type,
                        'reference_id': reference_id,
                        'role_broadcast': role
                    }
                }
            )


class AuditLogService:
    """
    Banking-grade audit logging service for immutable audit trails.
    """

    @classmethod
    def log(cls, user, action: str, application_number: str = None, 
            previous_status: str = None, new_status: str = None, 
            remarks: str = "", ip_address: str = None):
        
        user_role = user.role if (user and hasattr(user, 'role')) else 'SYSTEM'
        return AuditLog.objects.create(
            user=user if (user and user.is_authenticated) else None,
            user_role=user_role,
            action=action,
            application_number=application_number,
            previous_status=previous_status,
            new_status=new_status,
            remarks=remarks,
            ip_address=ip_address
        )
