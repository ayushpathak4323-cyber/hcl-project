from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    CustomLoginView,
    RegisterCustomerView,
    UserProfileView,
    NotificationListView,
    MarkNotificationsReadView,
    AuditLogListView
)

urlpatterns = [
    path('auth/login/', CustomLoginView.as_view(), name='auth_login'),
    path('auth/register/', RegisterCustomerView.as_view(), name='auth_register'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='auth_refresh'),
    path('auth/me/', UserProfileView.as_view(), name='user_profile'),
    path('notifications/', NotificationListView.as_view(), name='notification_list'),
    path('notifications/mark-read/', MarkNotificationsReadView.as_view(), name='notifications_mark_read'),
    path('audit-logs/', AuditLogListView.as_view(), name='audit_log_list'),
]
