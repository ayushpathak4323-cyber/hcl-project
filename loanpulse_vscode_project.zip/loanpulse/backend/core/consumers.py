import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from rest_framework_simplejwt.tokens import AccessToken
from django.contrib.auth import get_user_model

User = get_user_model()

class LoanPulseConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer handling real-time push notifications for
    Customers, Employees, and Managers.
    """

    async def connect(self):
        # Extract JWT token from query string if present
        query_string = self.scope.get('query_string', b'').decode('utf-8')
        token = None
        for param in query_string.split('&'):
            if param.startswith('token='):
                token = param.split('=')[1]
                break

        self.user = None
        if token:
            self.user = await self.get_user_from_token(token)

        await self.accept()

        if self.user:
            # Join user's individual notification group
            self.user_group = f"user_{self.user.id}"
            await self.channel_layer.group_add(self.user_group, self.channel_name)

            # Join role group (role_CUSTOMER, role_EMPLOYEE, role_MANAGER)
            self.role_group = f"role_{self.user.role}"
            await self.channel_layer.group_add(self.role_group, self.channel_name)

            await self.send(text_data=json.dumps({
                'type': 'CONNECTION_ESTABLISHED',
                'user': self.user.username,
                'role': self.user.role,
                'message': f"Connected to LoanPulse live notifications as {self.user.role}"
            }))
        else:
            # Public / Demo connection
            await self.channel_layer.group_add("loanpulse_global", self.channel_name)
            await self.send(text_data=json.dumps({
                'type': 'CONNECTION_ESTABLISHED',
                'message': "Connected to LoanPulse global channel"
            }))

    async def disconnect(self, close_code):
        if hasattr(self, 'user_group'):
            await self.channel_layer.group_discard(self.user_group, self.channel_name)
        if hasattr(self, 'role_group'):
            await self.channel_layer.group_discard(self.role_group, self.channel_name)
        await self.channel_layer.group_discard("loanpulse_global", self.channel_name)

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            if data.get('action') == 'ping':
                await self.send(text_data=json.dumps({'type': 'pong'}))
        except Exception:
            pass

    async def notify(self, event):
        """Handler for group messages sent via channel_layer"""
        await self.send(text_data=json.dumps({
            'type': 'NOTIFICATION',
            'payload': event['data']
        }))

    @database_sync_to_async
    def get_user_from_token(self, token_str):
        try:
            access_token = AccessToken(token_str)
            user_id = access_token['user_id']
            return User.objects.get(id=user_id)
        except Exception:
            return None
