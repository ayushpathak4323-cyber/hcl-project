from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    class Role(models.TextChoices):
        CUSTOMER = 'CUSTOMER', 'Customer'
        EMPLOYEE = 'EMPLOYEE', 'Employee / Loan Officer'
        MANAGER = 'MANAGER', 'Manager / Senior Underwriter'

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.CUSTOMER)
    phone = models.CharField(max_length=15, blank=True)
    employee_id = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        db_table = 'LP_USERS'

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"


class CustomerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='customer_profile')
    dob = models.DateField(null=True, blank=True)
    pan_number = models.CharField(max_length=10, blank=True)
    aadhaar_last_four = models.CharField(max_length=4, blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    employment_status = models.CharField(max_length=50, default='Salaried')
    employment_type = models.CharField(max_length=50, default='Full-time')
    company_name = models.CharField(max_length=150, blank=True)
    monthly_income = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    existing_loans = models.IntegerField(default=0)
    existing_monthly_emi = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    cibil_score = models.IntegerField(default=750)
    bank_account_number = models.CharField(max_length=30, blank=True)
    bank_ifsc = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'LP_CUSTOMERS'

    def __str__(self):
        return f"Customer: {self.user.get_full_name() or self.user.username}"


class EmployeeProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='employee_profile')
    employee_code = models.CharField(max_length=30, unique=True)
    department = models.CharField(max_length=100, default='Loan Verification')
    designation = models.CharField(max_length=100, default='Loan Officer')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_EMPLOYEES'

    def __str__(self):
        return f"Employee [{self.employee_code}]: {self.user.get_full_name()}"


class ManagerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='manager_profile')
    manager_code = models.CharField(max_length=30, unique=True)
    approval_limit = models.DecimalField(max_digits=14, decimal_places=2, default=10000000.00)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_MANAGERS'

    def __str__(self):
        return f"Manager [{self.manager_code}]: {self.user.get_full_name()}"


class AuditLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='audit_logs')
    user_role = models.CharField(max_length=30)
    action = models.CharField(max_length=120)
    application_number = models.CharField(max_length=50, blank=True, null=True)
    previous_status = models.CharField(max_length=50, blank=True, null=True)
    new_status = models.CharField(max_length=50, blank=True, null=True)
    remarks = models.TextField(blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_AUDIT_LOGS'
        ordering = ['-timestamp']

    def __str__(self):
        return f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] {self.user_role} - {self.action} on {self.application_number}"


class Notification(models.Model):
    class NotificationType(models.TextChoices):
        APPLICATION_SUBMITTED = 'APPLICATION_SUBMITTED', 'New Application Submitted'
        DOCUMENT_REJECTED = 'DOCUMENT_REJECTED', 'Document Rejected'
        EMPLOYEE_VERIFIED = 'EMPLOYEE_VERIFIED', 'Employee Verification Completed'
        LOAN_APPROVED = 'LOAN_APPROVED', 'Loan Approved'
        LOAN_REJECTED = 'LOAN_REJECTED', 'Loan Rejected'
        MORE_INFO_REQUESTED = 'MORE_INFO_REQUESTED', 'More Information Requested'
        EMI_DUE = 'EMI_DUE', 'EMI Approaching'
        EMI_OVERDUE = 'EMI_OVERDUE', 'EMI Overdue Alert'
        GENERAL = 'GENERAL', 'General Alert'

    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=50, choices=NotificationType.choices, default=NotificationType.GENERAL)
    reference_id = models.CharField(max_length=50, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_NOTIFICATIONS'
        ordering = ['-created_at']

    def __str__(self):
        return f"Notification to {self.recipient.username}: {self.title}"
