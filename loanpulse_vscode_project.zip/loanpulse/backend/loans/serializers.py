from rest_framework import serializers
from .models import LoanProduct, LoanApplication, VerificationReport, Loan, EMISchedule, Payment
from documents.serializers import DocumentSerializer
from risk.models import RiskAssessment
from core.models import CustomerProfile

class LoanProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = LoanProduct
        fields = '__all__'


class RiskAssessmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskAssessment
        fields = '__all__'


class VerificationReportSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()

    class Meta:
        model = VerificationReport
        fields = '__all__'

    def get_employee_name(self, obj):
        return obj.employee.get_full_name() or obj.employee.username


class EMIScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = EMISchedule
        fields = '__all__'


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = '__all__'


class LoanSerializer(serializers.ModelSerializer):
    emi_schedules = EMIScheduleSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    customer_email = serializers.CharField(source='customer.email', read_only=True)
    application_number = serializers.CharField(source='application.application_number', read_only=True)
    paid_emis_count = serializers.SerializerMethodField()
    remaining_emis_count = serializers.SerializerMethodField()
    total_paid_amount = serializers.SerializerMethodField()

    class Meta:
        model = Loan
        fields = '__all__'

    def get_paid_emis_count(self, obj):
        return obj.emi_schedules.filter(status='PAID').count()

    def get_remaining_emis_count(self, obj):
        return obj.emi_schedules.filter(status__in=['PENDING', 'OVERDUE']).count()

    def get_total_paid_amount(self, obj):
        return sum([p.amount_paid for p in obj.payments.filter(payment_status='SUCCESS')])


class LoanApplicationListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    customer_email = serializers.CharField(source='customer.email', read_only=True)
    loan_product_name = serializers.CharField(source='loan_product.name', read_only=True)
    risk_score = serializers.SerializerMethodField()
    risk_level = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = LoanApplication
        fields = [
            'id', 'application_number', 'customer', 'customer_name', 'customer_email',
            'loan_product', 'loan_product_name', 'loan_purpose', 'requested_amount',
            'tenure_months', 'interest_rate', 'calculated_emi', 'cibil_score', 'status', 'status_display',
            'risk_score', 'risk_level', 'created_at', 'updated_at'
        ]

    def get_risk_score(self, obj):
        if hasattr(obj, 'risk_assessment'):
            return obj.risk_assessment.score
        return None

    def get_risk_level(self, obj):
        if hasattr(obj, 'risk_assessment'):
            return obj.risk_assessment.risk_level
        return None


class LoanApplicationDetailSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    customer_email = serializers.CharField(source='customer.email', read_only=True)
    customer_phone = serializers.CharField(source='customer.phone', read_only=True)
    customer_profile = serializers.SerializerMethodField()
    loan_product_name = serializers.CharField(source='loan_product.name', read_only=True)
    documents = DocumentSerializer(many=True, read_only=True)
    risk_assessment = RiskAssessmentSerializer(read_only=True)
    verification_report = VerificationReportSerializer(read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    disbursed_loan = LoanSerializer(read_only=True)

    class Meta:
        model = LoanApplication
        fields = '__all__'

    def get_customer_profile(self, obj):
        if hasattr(obj.customer, 'customer_profile'):
            profile = obj.customer.customer_profile
            return {
                'dob': str(profile.dob) if profile.dob else None,
                'pan_number': profile.pan_number,
                'monthly_income': float(profile.monthly_income),
                'company_name': profile.company_name,
                'employment_status': profile.employment_status,
                'employment_type': profile.employment_type,
                'existing_loans': profile.existing_loans,
                'existing_monthly_emi': float(profile.existing_monthly_emi),
                'cibil_score': profile.cibil_score,
                'address': profile.address,
                'city': profile.city,
                'state': profile.state,
                'pincode': profile.pincode,
                'bank_account_number': profile.bank_account_number,
                'bank_ifsc': profile.bank_ifsc
            }
        return {}
