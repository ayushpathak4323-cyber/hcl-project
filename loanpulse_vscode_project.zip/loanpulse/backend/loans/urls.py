from django.urls import path
from .views import (
    LoanProductListView,
    EMICalculatorPreviewView,
    CustomerLoanApplicationView,
    EmployeeApplicationListView,
    ApplicationDetailView,
    EmployeeSubmitVerificationReportView,
    ManagerDashboardStatsView,
    ManagerDecisionView,
    CustomerActiveLoansView,
    EMIPaymentSimulationView,
    SimulateOverdueView
)

urlpatterns = [
    # Products & Calculations
    path('products/', LoanProductListView.as_view(), name='loan_products'),
    path('calculate-emi/', EMICalculatorPreviewView.as_view(), name='calculate_emi'),

    # Customer Endpoints
    path('customer/applications/', CustomerLoanApplicationView.as_view(), name='customer_applications'),
    path('customer/active-loans/', CustomerActiveLoansView.as_view(), name='customer_active_loans'),
    path('customer/pay-emi/<int:pk>/', EMIPaymentSimulationView.as_view(), name='customer_pay_emi'),

    # Employee Endpoints
    path('employee/applications/', EmployeeApplicationListView.as_view(), name='employee_applications'),
    path('employee/applications/<int:pk>/submit-report/', EmployeeSubmitVerificationReportView.as_view(), name='employee_submit_report'),

    # Manager Endpoints
    path('manager/stats/', ManagerDashboardStatsView.as_view(), name='manager_stats'),
    path('manager/applications/<int:pk>/decision/', ManagerDecisionView.as_view(), name='manager_decision'),

    # Shared Details & Simulations
    path('applications/<int:pk>/', ApplicationDetailView.as_view(), name='application_detail'),
    path('simulate-overdue/<int:pk>/', SimulateOverdueView.as_view(), name='simulate_overdue'),
]
