from django.db import models
from django.conf import settings

class LoanProduct(models.Model):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=100)
    interest_rate_min = models.DecimalField(max_digits=5, decimal_places=2)
    interest_rate_max = models.DecimalField(max_digits=5, decimal_places=2)
    min_amount = models.DecimalField(max_digits=12, decimal_places=2)
    max_amount = models.DecimalField(max_digits=12, decimal_places=2)
    min_tenure_months = models.IntegerField(default=6)
    max_tenure_months = models.IntegerField(default=60)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'LP_LOAN_PRODUCTS'

    def __str__(self):
        return f"{self.name} ({self.interest_rate_min}% - {self.interest_rate_max}%)"


class LoanApplication(models.Model):
    class Status(models.TextChoices):
        DRAFT = 'DRAFT', 'Draft'
        SUBMITTED = 'SUBMITTED', 'Submitted'
        UNDER_REVIEW = 'UNDER_REVIEW', 'Under Review'
        DOCUMENTS_REJECTED = 'DOCUMENTS_REJECTED', 'Documents Rejected'
        EMPLOYEE_VERIFIED = 'EMPLOYEE_VERIFIED', 'Employee Verified'
        APPROVED = 'APPROVED', 'Approved by Manager'
        REJECTED = 'REJECTED', 'Rejected'
        MORE_INFO_REQUESTED = 'MORE_INFO_REQUESTED', 'More Information Requested'

    application_number = models.CharField(max_length=50, unique=True)
    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='loan_applications'
    )
    loan_product = models.ForeignKey(
        LoanProduct,
        on_delete=models.PROTECT,
        related_name='applications'
    )
    loan_purpose = models.CharField(max_length=200)
    requested_amount = models.DecimalField(max_digits=12, decimal_places=2)
    tenure_months = models.IntegerField()
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2)
    calculated_emi = models.DecimalField(max_digits=12, decimal_places=2)
    total_interest = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    total_repayment = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    cibil_score = models.IntegerField(default=750)
    
    status = models.CharField(max_length=40, choices=Status.choices, default=Status.DRAFT)
    assigned_employee = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='assigned_employee_applications'
    )
    assigned_manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='assigned_manager_applications'
    )
    employee_remarks = models.TextField(blank=True)
    manager_remarks = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'LP_LOAN_APPLICATIONS'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.application_number} - {self.customer.get_full_name()} ({self.status})"


class VerificationReport(models.Model):
    application = models.OneToOneField(
        LoanApplication,
        on_delete=models.CASCADE,
        related_name='verification_report'
    )
    employee = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='submitted_verification_reports'
    )
    overall_recommendation = models.CharField(max_length=50, default='RECOMMENDED_APPROVAL')
    remarks = models.TextField(blank=True)
    risk_score_snapshot = models.IntegerField(default=0)
    risk_level_snapshot = models.CharField(max_length=20, default='MEDIUM')
    documents_summary = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_VERIFICATION_REPORTS'

    def __str__(self):
        return f"Report for {self.application.application_number} by {self.employee.username}"


class Loan(models.Model):
    class LoanStatus(models.TextChoices):
        ACTIVE = 'ACTIVE', 'Active'
        CLOSED = 'CLOSED', 'Closed'
        DEFAULTED = 'DEFAULTED', 'Defaulted'

    loan_account_number = models.CharField(max_length=50, unique=True)
    application = models.OneToOneField(
        LoanApplication,
        on_delete=models.CASCADE,
        related_name='disbursed_loan'
    )
    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='active_loans'
    )
    approved_amount = models.DecimalField(max_digits=12, decimal_places=2)
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2)
    tenure_months = models.IntegerField()
    monthly_emi = models.DecimalField(max_digits=12, decimal_places=2)
    total_interest = models.DecimalField(max_digits=12, decimal_places=2)
    total_payable = models.DecimalField(max_digits=12, decimal_places=2)
    disbursed_amount = models.DecimalField(max_digits=12, decimal_places=2)
    disbursement_date = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=30, choices=LoanStatus.choices, default=LoanStatus.ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_LOANS'
        ordering = ['-created_at']

    def __str__(self):
        return f"Loan {self.loan_account_number} - ₹{self.approved_amount:,.2f}"


class EMISchedule(models.Model):
    class EMIStatus(models.TextChoices):
        PENDING = 'PENDING', 'Pending'
        PAID = 'PAID', 'Paid'
        OVERDUE = 'OVERDUE', 'Overdue'

    loan = models.ForeignKey(
        Loan,
        on_delete=models.CASCADE,
        related_name='emi_schedules'
    )
    installment_number = models.IntegerField()
    due_date = models.DateField()
    emi_amount = models.DecimalField(max_digits=12, decimal_places=2)
    principal_component = models.DecimalField(max_digits=12, decimal_places=2)
    interest_component = models.DecimalField(max_digits=12, decimal_places=2)
    remaining_principal = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=30, choices=EMIStatus.choices, default=EMIStatus.PENDING)
    paid_date = models.DateField(null=True, blank=True)
    transaction_reference = models.CharField(max_length=100, blank=True)

    class Meta:
        db_table = 'LP_EMI_SCHEDULES'
        ordering = ['installment_number']

    def __str__(self):
        return f"EMI #{self.installment_number} for {self.loan.loan_account_number} (Due: {self.due_date})"


class Payment(models.Model):
    loan = models.ForeignKey(
        Loan,
        on_delete=models.CASCADE,
        related_name='payments'
    )
    emi_schedule = models.ForeignKey(
        EMISchedule,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='payments'
    )
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2)
    payment_method = models.CharField(max_length=50, default='SIMULATED_NET_BANKING')
    payment_status = models.CharField(max_length=30, default='SUCCESS')
    transaction_reference = models.CharField(max_length=100, unique=True)
    paid_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'LP_PAYMENTS'
        ordering = ['-paid_at']

    def __str__(self):
        return f"Payment {self.transaction_reference} - ₹{self.amount_paid}"
