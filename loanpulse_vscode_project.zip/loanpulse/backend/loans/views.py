import random
from datetime import datetime, date
from decimal import Decimal
from rest_framework import views, generics, permissions, status
from rest_framework.response import Response
from django.db import transaction
from django.utils import timezone
from .models import LoanProduct, LoanApplication, VerificationReport, Loan, EMISchedule, Payment
from .serializers import (
    LoanProductSerializer,
    LoanApplicationListSerializer,
    LoanApplicationDetailSerializer,
    VerificationReportSerializer,
    LoanSerializer,
    EMIScheduleSerializer
)
from .services import EMICalculatorService
from documents.models import Document
from risk.models import RiskAssessment
from risk.services import RiskAssessmentService
from core.models import CustomerProfile, Notification, User
from core.services import NotificationService, AuditLogService
from core.views import IsCustomer, IsEmployee, IsManager, IsStaffOrManager

class LoanProductListView(generics.ListAPIView):
    queryset = LoanProduct.objects.filter(is_active=True)
    serializer_class = LoanProductSerializer
    permission_classes = [permissions.AllowAny]


class EMICalculatorPreviewView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request, *args, **kwargs):
        try:
            amount = Decimal(str(request.data.get('amount', 100000)))
            rate = Decimal(str(request.data.get('interest_rate', 10.5)))
            tenure = int(request.data.get('tenure_months', 12))

            result = EMICalculatorService.calculate_emi(amount, rate, tenure)
            return Response({
                'requested_amount': amount,
                'interest_rate': rate,
                'tenure_months': tenure,
                'calculated_emi': result['emi'],
                'total_interest': result['total_interest'],
                'total_repayment': result['total_repayment']
            })
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class CustomerLoanApplicationView(views.APIView):
    permission_classes = [IsCustomer]

    def get(self, request):
        applications = LoanApplication.objects.filter(customer=request.user).order_by('-created_at')
        serializer = LoanApplicationListSerializer(applications, many=True)
        return Response(serializer.data)

    @transaction.atomic
    def post(self, request):
        data = request.data
        user = request.user

        # 1. Update or create CustomerProfile with latest submitted details
        profile, _ = CustomerProfile.objects.get_or_create(user=user)
        if data.get('monthly_income') is not None:
            profile.monthly_income = Decimal(str(data.get('monthly_income', 0)))
        if data.get('company_name'):
            profile.company_name = data.get('company_name')
        if data.get('employment_status'):
            profile.employment_status = data.get('employment_status')
        if data.get('employment_type'):
            profile.employment_type = data.get('employment_type')
        if data.get('existing_loans') is not None:
            profile.existing_loans = int(data.get('existing_loans', 0))
        if data.get('existing_monthly_emi') is not None:
            profile.existing_monthly_emi = Decimal(str(data.get('existing_monthly_emi', 0)))
        if data.get('pan_number'):
            profile.pan_number = data.get('pan_number')
        if data.get('aadhaar_last_four'):
            profile.aadhaar_last_four = data.get('aadhaar_last_four')
        if data.get('address'):
            profile.address = data.get('address')
        if data.get('city'):
            profile.city = data.get('city')
        if data.get('state'):
            profile.state = data.get('state')
        if data.get('pincode'):
            profile.pincode = data.get('pincode')
        if data.get('bank_account_number'):
            profile.bank_account_number = data.get('bank_account_number')
        cibil_score = int(data.get('cibil_score', profile.cibil_score or 750))
        profile.cibil_score = cibil_score
        profile.save()

        # 2. Validate loan product & amounts
        product_id = data.get('loan_product_id')
        loan_product = LoanProduct.objects.filter(id=product_id).first()
        if not loan_product:
            loan_product = LoanProduct.objects.first()

        requested_amount = Decimal(str(data.get('requested_amount', 200000)))
        tenure_months = int(data.get('tenure_months', 24))
        interest_rate = loan_product.interest_rate_min if loan_product else Decimal('10.50')

        # 3. Calculate EMI
        emi_calc = EMICalculatorService.calculate_emi(requested_amount, interest_rate, tenure_months)

        # 4. Generate Unique Application ID (e.g. LP10294)
        random_num = random.randint(10000, 99999)
        app_num = f"LP{random_num}"

        # 5. Create Loan Application record
        application = LoanApplication.objects.create(
            application_number=app_num,
            customer=user,
            loan_product=loan_product,
            loan_purpose=data.get('loan_purpose', 'Personal Needs'),
            requested_amount=requested_amount,
            tenure_months=tenure_months,
            interest_rate=interest_rate,
            calculated_emi=emi_calc['emi'],
            total_interest=emi_calc['total_interest'],
            total_repayment=emi_calc['total_repayment'],
            cibil_score=cibil_score,
            status=LoanApplication.Status.SUBMITTED
        )

        # 6. Associate uploaded documents (if any passed by ID)
        doc_ids = data.get('document_ids', [])
        if doc_ids:
            Document.objects.filter(id__in=doc_ids, customer=user).update(application=application)

        # 7. Generate preliminary Risk Assessment
        risk_result = RiskAssessmentService.evaluate(
            monthly_income=profile.monthly_income,
            employment_status=profile.employment_status,
            employment_type=profile.employment_type,
            company_name=profile.company_name,
            existing_loans=profile.existing_loans,
            existing_monthly_emi=profile.existing_monthly_emi,
            requested_amount=requested_amount,
            tenure_months=tenure_months,
            calculated_emi=emi_calc['emi'],
            cibil_score=cibil_score
        )

        RiskAssessment.objects.create(
            application=application,
            score=risk_result['score'],
            risk_level=risk_result['risk_level'],
            cibil_score=cibil_score,
            cibil_rating_score=risk_result['breakdown']['cibil_score']['score'],
            debt_to_income_ratio=risk_result['dti_ratio'],
            loan_to_income_ratio=risk_result['lti_multiplier'],
            income_stability_score=risk_result['breakdown']['income_stability_score']['score'],
            existing_debt_score=risk_result['breakdown']['debt_burden_score']['score'],
            dti_score=risk_result['breakdown']['dti_score']['score'],
            repayment_history_score=risk_result['breakdown']['repayment_score']['score'],
            loan_amount_suitability_score=risk_result['breakdown']['lti_score']['score'],
            factors_breakdown=risk_result['breakdown'],
            recommendation_summary=risk_result['recommendation_summary'],
            ai_generated_explanation=risk_result['ai_generated_explanation']
        )

        # 8. Banking Audit Trail
        AuditLogService.log(
            user=user,
            action="SUBMIT_LOAN_APPLICATION",
            application_number=app_num,
            previous_status=None,
            new_status="SUBMITTED",
            remarks=f"Customer submitted application for ₹{requested_amount:,.2f} under {loan_product.name}"
        )

        # 9. Real-time push notification to all loan officers (Employees)
        customer_name = user.get_full_name() or user.username
        NotificationService.broadcast_to_role(
            role='EMPLOYEE',
            title=f"🔔 New Loan Application Received — Application #{app_num}",
            message=f"New application submitted by {customer_name} for ₹{requested_amount:,.2f}. Ready for document verification.",
            notification_type=Notification.NotificationType.APPLICATION_SUBMITTED,
            reference_id=app_num
        )

        # 10. Confirmation notification for the Customer
        NotificationService.notify_user(
            recipient=user,
            title="Loan Application Submitted",
            message=f"Your loan application #{app_num} has been successfully submitted and routed for verification.",
            notification_type=Notification.NotificationType.APPLICATION_SUBMITTED,
            reference_id=app_num
        )

        return Response(LoanApplicationDetailSerializer(application).data, status=status.HTTP_201_CREATED)


class EmployeeApplicationListView(views.APIView):
    permission_classes = [IsStaffOrManager]

    def get(self, request):
        qs = LoanApplication.objects.all().order_by('-created_at')

        # Filter by status if requested
        status_param = request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)

        # Metrics for Dashboard Cards
        total_count = LoanApplication.objects.count()
        pending_verification = LoanApplication.objects.filter(status__in=['SUBMITTED', 'UNDER_REVIEW']).count()
        docs_pending = Document.objects.filter(verification_status='PENDING').count()
        verified_count = LoanApplication.objects.filter(status='EMPLOYEE_VERIFIED').count()
        rejected_count = LoanApplication.objects.filter(status='REJECTED').count()

        serializer = LoanApplicationListSerializer(qs, many=True)
        return Response({
            'metrics': {
                'total_applications': total_count,
                'pending_verification': pending_verification,
                'documents_pending': docs_pending,
                'verified': verified_count,
                'rejected': rejected_count
            },
            'applications': serializer.data
        })


class ApplicationDetailView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        app = LoanApplication.objects.filter(id=pk).first()
        if not app:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)

        # Access check
        if request.user.role == User.Role.CUSTOMER and app.customer != request.user:
            return Response({'error': 'Unauthorized'}, status=status.HTTP_403_FORBIDDEN)

        # If Employee opens a newly SUBMITTED application, update status to UNDER_REVIEW
        if request.user.role == User.Role.EMPLOYEE and app.status == LoanApplication.Status.SUBMITTED:
            prev_status = app.status
            app.status = LoanApplication.Status.UNDER_REVIEW
            app.assigned_employee = request.user
            app.save()

            AuditLogService.log(
                user=request.user,
                action="START_REVIEW",
                application_number=app.application_number,
                previous_status=prev_status,
                new_status="UNDER_REVIEW",
                remarks=f"Loan Officer {request.user.get_full_name()} commenced verification."
            )

        serializer = LoanApplicationDetailSerializer(app)
        return Response(serializer.data)


class EmployeeSubmitVerificationReportView(views.APIView):
    permission_classes = [IsEmployee]

    @transaction.atomic
    def post(self, request, pk):
        app = LoanApplication.objects.filter(id=pk).first()
        if not app:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)

        recommendation = request.data.get('recommendation', 'RECOMMENDED_APPROVAL')
        remarks = request.data.get('remarks', '')

        # Summarize documents
        docs = app.documents.all()
        doc_summary = {
            'total': docs.count(),
            'verified': docs.filter(verification_status__in=['VERIFIED', 'AUTO_VERIFIED']).count(),
            'rejected': docs.filter(verification_status='REJECTED').count(),
            'pending': docs.filter(verification_status='PENDING').count()
        }

        risk_score = app.risk_assessment.score if hasattr(app, 'risk_assessment') else 0
        risk_level = app.risk_assessment.risk_level if hasattr(app, 'risk_assessment') else 'MEDIUM'

        # Create or update VerificationReport
        report, _ = VerificationReport.objects.update_or_create(
            application=app,
            defaults={
                'employee': request.user,
                'overall_recommendation': recommendation,
                'remarks': remarks,
                'risk_score_snapshot': risk_score,
                'risk_level_snapshot': risk_level,
                'documents_summary': doc_summary
            }
        )

        prev_status = app.status
        app.status = LoanApplication.Status.EMPLOYEE_VERIFIED
        app.employee_remarks = remarks
        app.assigned_employee = request.user
        app.save()

        # Audit log
        emp_code = request.user.employee_id or f"EMP{request.user.id}"
        AuditLogService.log(
            user=request.user,
            action="SUBMIT_VERIFICATION_REPORT",
            application_number=app.application_number,
            previous_status=prev_status,
            new_status="EMPLOYEE_VERIFIED",
            remarks=f"Employee {emp_code} submitted report: {recommendation}. Remarks: {remarks}"
        )

        # Notify Managers in real time
        NotificationService.broadcast_to_role(
            role='MANAGER',
            title=f"Verification Complete — Application #{app.application_number}",
            message=f"Application {app.application_number} has been verified by Employee {emp_code} and requires final manager review.",
            notification_type=Notification.NotificationType.EMPLOYEE_VERIFIED,
            reference_id=app.application_number
        )

        return Response({
            'status': 'EMPLOYEE_VERIFIED',
            'report': VerificationReportSerializer(report).data,
            'application': LoanApplicationDetailSerializer(app).data
        })


class ManagerDashboardStatsView(views.APIView):
    permission_classes = [IsManager]

    def get(self, request):
        total_apps = LoanApplication.objects.count()
        emp_verified = LoanApplication.objects.filter(status='EMPLOYEE_VERIFIED').count()
        pending_review = LoanApplication.objects.filter(status__in=['SUBMITTED', 'UNDER_REVIEW', 'EMPLOYEE_VERIFIED']).count()
        approved = LoanApplication.objects.filter(status='APPROVED').count()
        rejected = LoanApplication.objects.filter(status='REJECTED').count()
        active_loans = Loan.objects.filter(status='ACTIVE').count()

        total_disbursed = sum([loan.approved_amount for loan in Loan.objects.all()])
        overdue_emis = EMISchedule.objects.filter(status='OVERDUE').count()

        return Response({
            'total_applications': total_apps,
            'employee_verified_applications': emp_verified,
            'pending_final_review': pending_review,
            'approved_loans': approved,
            'rejected_loans': rejected,
            'active_loans': active_loans,
            'total_disbursed': float(total_disbursed),
            'overdue_loans': overdue_emis
        })


class ManagerDecisionView(views.APIView):
    permission_classes = [IsManager]

    @transaction.atomic
    def post(self, request, pk):
        app = LoanApplication.objects.filter(id=pk).first()
        if not app:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)

        decision = request.data.get('decision') # 'APPROVE', 'REJECT', 'REQUEST_INFO'
        remarks = request.data.get('remarks', '')
        prev_status = app.status

        mgr_code = request.user.employee_id or f"MGR{request.user.id}"

        if decision == 'APPROVE':
            app.status = LoanApplication.Status.APPROVED
            app.manager_remarks = remarks
            app.assigned_manager = request.user
            app.save()

            # Mock Disbursement: Create Loan Record
            loan_acc_no = f"LN-{datetime.now().year}-{app.id:05d}"
            loan = Loan.objects.create(
                loan_account_number=loan_acc_no,
                application=app,
                customer=app.customer,
                approved_amount=app.requested_amount,
                interest_rate=app.interest_rate,
                tenure_months=app.tenure_months,
                monthly_emi=app.calculated_emi,
                total_interest=app.total_interest,
                total_payable=app.total_repayment,
                disbursed_amount=app.requested_amount,
                status=Loan.LoanStatus.ACTIVE
            )

            # Generate Amortization EMI Schedules
            schedule_items = EMICalculatorService.generate_amortization_schedule(
                principal=app.requested_amount,
                annual_rate=app.interest_rate,
                tenure_months=app.tenure_months,
                start_date=date.today()
            )
            for item in schedule_items:
                EMISchedule.objects.create(
                    loan=loan,
                    installment_number=item['installment_number'],
                    due_date=item['due_date'],
                    emi_amount=item['emi_amount'],
                    principal_component=item['principal_component'],
                    interest_component=item['interest_component'],
                    remaining_principal=item['remaining_principal'],
                    status=EMISchedule.EMIStatus.PENDING
                )

            # Log audit
            AuditLogService.log(
                user=request.user,
                action="APPROVE_LOAN",
                application_number=app.application_number,
                previous_status=prev_status,
                new_status="APPROVED",
                remarks=f"Manager {mgr_code} approved loan. Disbursed #{loan_acc_no} for ₹{app.requested_amount:,.2f}"
            )

            # Notify Customer
            NotificationService.notify_user(
                recipient=app.customer,
                title="🎉 Loan Approved & Disbursed!",
                message=f"Congratulations! Your loan #{app.application_number} of ₹{app.requested_amount:,.2f} has been approved. Loan Account: {loan_acc_no}.",
                notification_type=Notification.NotificationType.LOAN_APPROVED,
                reference_id=loan_acc_no
            )

            return Response({
                'status': 'APPROVED',
                'loan': LoanSerializer(loan).data,
                'application': LoanApplicationDetailSerializer(app).data
            })

        elif decision == 'REJECT':
            app.status = LoanApplication.Status.REJECTED
            app.manager_remarks = remarks
            app.assigned_manager = request.user
            app.save()

            AuditLogService.log(
                user=request.user,
                action="REJECT_LOAN",
                application_number=app.application_number,
                previous_status=prev_status,
                new_status="REJECTED",
                remarks=f"Manager {mgr_code} rejected loan. Reason: {remarks}"
            )

            NotificationService.notify_user(
                recipient=app.customer,
                title="Loan Application Decision",
                message=f"We regret to inform you that loan application #{app.application_number} could not be approved at this time. Reason: {remarks}",
                notification_type=Notification.NotificationType.LOAN_REJECTED,
                reference_id=app.application_number
            )

            return Response({'status': 'REJECTED', 'application': LoanApplicationDetailSerializer(app).data})

        elif decision == 'REQUEST_INFO':
            app.status = LoanApplication.Status.MORE_INFO_REQUESTED
            app.manager_remarks = remarks
            app.save()

            AuditLogService.log(
                user=request.user,
                action="REQUEST_MORE_INFO",
                application_number=app.application_number,
                previous_status=prev_status,
                new_status="MORE_INFO_REQUESTED",
                remarks=f"Manager requested clarification: {remarks}"
            )

            NotificationService.notify_user(
                recipient=app.customer,
                title="Additional Information Needed",
                message=f"Manager has requested additional information regarding application #{app.application_number}: {remarks}",
                notification_type=Notification.NotificationType.MORE_INFO_REQUESTED,
                reference_id=app.application_number
            )

            return Response({'status': 'MORE_INFO_REQUESTED', 'application': LoanApplicationDetailSerializer(app).data})

        return Response({'error': 'Invalid decision'}, status=status.HTTP_400_BAD_REQUEST)


class CustomerActiveLoansView(views.APIView):
    permission_classes = [IsCustomer]

    def get(self, request):
        loans = Loan.objects.filter(customer=request.user).order_by('-created_at')
        serializer = LoanSerializer(loans, many=True)
        return Response(serializer.data)


class EMIPaymentSimulationView(views.APIView):
    """
    Simulated repayment portal for customer demo.
    Allows paying individual EMIs, updates amortization, and records transaction.
    """
    permission_classes = [IsCustomer]

    @transaction.atomic
    def post(self, request, pk):
        emi = EMISchedule.objects.filter(id=pk, loan__customer=request.user).first()
        if not emi:
            return Response({'error': 'EMI installment not found'}, status=status.HTTP_404_NOT_FOUND)

        if emi.status == 'PAID':
            return Response({'error': 'This installment is already paid'}, status=status.HTTP_400_BAD_REQUEST)

        # Mark as PAID
        tx_ref = f"TXN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{random.randint(100, 999)}"
        emi.status = EMISchedule.EMIStatus.PAID
        emi.paid_date = date.today()
        emi.transaction_reference = tx_ref
        emi.save()

        # Create payment record
        Payment.objects.create(
            loan=emi.loan,
            emi_schedule=emi,
            amount_paid=emi.emi_amount,
            payment_method='SIMULATED_UPI_NETBANKING',
            payment_status='SUCCESS',
            transaction_reference=tx_ref
        )

        # Check if all installments are paid
        pending_count = emi.loan.emi_schedules.filter(status__in=['PENDING', 'OVERDUE']).count()
        if pending_count == 0:
            emi.loan.status = Loan.LoanStatus.CLOSED
            emi.loan.save()

        # Audit log
        AuditLogService.log(
            user=request.user,
            action="PAY_EMI",
            application_number=emi.loan.application.application_number,
            remarks=f"Customer completed payment of ₹{emi.emi_amount:,.2f} for Installment #{emi.installment_number} (Ref: {tx_ref})"
        )

        # Real-time notification
        NotificationService.notify_user(
            recipient=request.user,
            title="EMI Payment Successful",
            message=f"Received payment of ₹{emi.emi_amount:,.2f} for Loan Account #{emi.loan.loan_account_number}. Reference: {tx_ref}.",
            notification_type=Notification.NotificationType.GENERAL,
            reference_id=emi.loan.loan_account_number
        )

        return Response({
            'status': 'PAID',
            'transaction_reference': tx_ref,
            'emi': EMIScheduleSerializer(emi).data,
            'loan': LoanSerializer(emi.loan).data
        })


class SimulateOverdueView(views.APIView):
    """
    Simulation feature for testing overdue management and alerts.
    """
    permission_classes = [permissions.IsAuthenticated]

    @transaction.atomic
    def post(self, request, pk):
        emi = EMISchedule.objects.filter(id=pk).first()
        if not emi:
            return Response({'error': 'EMI installment not found'}, status=status.HTTP_404_NOT_FOUND)

        prev_status = emi.status
        emi.status = EMISchedule.EMIStatus.OVERDUE
        emi.save()

        # Send alert to customer
        NotificationService.notify_user(
            recipient=emi.loan.customer,
            title="⚠️ EMI Overdue Alert",
            message=f"Your EMI of ₹{emi.emi_amount:,.2f} for Loan #{emi.loan.loan_account_number} is overdue. Please settle promptly to avoid penalty.",
            notification_type=Notification.NotificationType.EMI_OVERDUE,
            reference_id=emi.loan.loan_account_number
        )

        # Audit log
        AuditLogService.log(
            user=request.user,
            action="SIMULATE_OVERDUE",
            application_number=emi.loan.application.application_number,
            previous_status=prev_status,
            new_status="OVERDUE",
            remarks=f"Overdue state simulated on Installment #{emi.installment_number} (Due: {emi.due_date})"
        )

        return Response({
            'status': 'OVERDUE',
            'emi': EMIScheduleSerializer(emi).data,
            'message': f"Installment #{emi.installment_number} marked as OVERDUE."
        })
