import math
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

class EMICalculatorService:
    """
    Standard banking reducing-balance EMI calculation and amortization schedule engine.
    """

    @classmethod
    def calculate_emi(cls, principal: Decimal, annual_rate: Decimal, tenure_months: int) -> dict:
        P = float(principal)
        R_annual = float(annual_rate)
        N = tenure_months

        if P <= 0 or N <= 0:
            return {
                'emi': Decimal('0.00'),
                'total_interest': Decimal('0.00'),
                'total_repayment': Decimal('0.00')
            }

        # Monthly interest rate
        r = (R_annual / 12.0) / 100.0

        if r == 0:
            emi = P / N
            total_interest = 0.0
        else:
            emi = (P * r * math.pow(1 + r, N)) / (math.pow(1 + r, N) - 1)
            total_repayment = emi * N
            total_interest = total_repayment - P

        emi_dec = Decimal(str(round(emi, 2))).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
        total_interest_dec = Decimal(str(round(total_interest, 2))).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
        total_repayment_dec = Decimal(str(round(emi * N, 2))).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)

        return {
            'emi': emi_dec,
            'total_interest': total_interest_dec,
            'total_repayment': total_repayment_dec
        }

    @classmethod
    def generate_amortization_schedule(cls, principal: Decimal, annual_rate: Decimal, tenure_months: int, start_date=None) -> list:
        if not start_date:
            start_date = date.today()

        calc = cls.calculate_emi(principal, annual_rate, tenure_months)
        emi = float(calc['emi'])
        r = (float(annual_rate) / 12.0) / 100.0
        balance = float(principal)

        schedule = []
        current_date = start_date

        for i in range(1, tenure_months + 1):
            # Advance roughly 1 month (30 days)
            due_date = current_date + timedelta(days=30 * i)
            
            interest_comp = balance * r
            principal_comp = emi - interest_comp

            # Adjust last installment rounding
            if i == tenure_months or principal_comp > balance:
                principal_comp = balance
                emi = principal_comp + interest_comp
                balance = 0.0
            else:
                balance -= principal_comp

            schedule.append({
                'installment_number': i,
                'due_date': due_date,
                'emi_amount': round(Decimal(str(round(emi, 2))), 2),
                'principal_component': round(Decimal(str(round(principal_comp, 2))), 2),
                'interest_component': round(Decimal(str(round(interest_comp, 2))), 2),
                'remaining_principal': round(Decimal(str(max(0.0, round(balance, 2)))), 2),
                'status': 'PENDING'
            })

        return schedule
